<?php

require('generate_dllfunctions.php');
require('dll_gml_generator.php');

?>
/*
 * Copyright 2009-2010 Maarten Baert
 * maarten-baert@hotmail.com
 * http://www.maartenbaert.be/
 * 
 * This file is part of ExtremePhysics.
 * 
 * ExtremePhysics is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ExtremePhysics is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with ExtremePhysics. If not, see <http://www.gnu.org/licenses/>.
 * 
 * File: ExtremePhysics.h
 * Include this file in your project to use the engine.
 */

#ifndef EXTREMEPHYSICS_H
#define EXTREMEPHYSICS_H

// ##### headers #####

#ifdef _MSC_VER
#define _USE_MATH_DEFINES // get M_PI
#endif

#include <cfloat>
#include <cmath>
#include <cstdarg>
#include <cstdio>
#include <cstdlib>
#include <cstring>

#if defined(_MSC_VER)
#define EP_FORCEINLINE __forceinline
#elif defined(_GNUC_)
#define EP_FORCEINLINE __attribute__((always_inline))
#else
#define EP_FORCEINLINE inline
#endif

// ##### settings #####

// debugging
// You can disable debug checks in release mode but your program
// might crash if you do something wrong. A few examples:
// - using a polygon that has not been initialized
// - using a polygon that belongs to a different world
// - trying to connect a body to itself with a hinge joint
// - trying to connect bodies that belong to a different world
// - trying to move a ground body
// - ...
// Memory allocation is always checked, even if you disable this.
#define EP_COMPILE_DEBUGCHECKS    1  // enable debug checks, e.g. 'can not create hinge joint, both bodies are static'
#define EP_COMPILE_DEBUGMESSAGES  1  // compile debug messages
#define EP_COMPILE_DEBUGDRAW      1  // compile debug drawing

// polygon decomposition (extension)
#define EP_COMPILE_MULTIPOLY 1
#define EP_MULTIPOLY_EPSILON_MINCROSSPRODUCT  1.0e-6  // this value should be smaller than EP_EPSILON_MAXCROSSPRODUCT
#define EP_MULTIPOLY_EPSILON_MINPOLYEDGELEN   1.0e-4  // this value should be greater than EP_EPSILON_MINPOLYEDGELEN

// box chains (extension)
#define EP_COMPILE_BOXCHAIN 1

// serialize (extension)
#define EP_COMPILE_SERIALIZE 1

// Enable this if you want to be able to throw exceptions in callback functions. If you
// don't enable this and an exception is thrown, there could be memory leaks.
#define EP_USE_EXCEPTIONS 0

// id hash table settings
// The id hash table can significantly improve id lookup times for bodies and contacts.
// If this is disabled, ExtremePhysics will fall back to the original id lookup system
// (i.e. traversing the entire list). You can disable the id hash table if you're not
// using the id system frequently.
#define EP_USE_IDHASHTABLE 1 // enable the id hash table
#define EP_IDHASHTABLE_BUCKETS_BITS 8 // the actual number of buckets is 2 to the power of EP_IDHASHTABLE_BUCKETS_BITS

// epsilon values used in floating-point calculations
#define EP_EPSILON_MINPOLYMASS       1.0e-20   // minimum mass (i.e. aera) for polygons
#define EP_EPSILON_MINPOLYINERTIA    1.0e-20   // minimum moment of inertia for polygons
#define EP_EPSILON_MINBODYMASS       1.0e-20   // minimum mass for bodies
#define EP_EPSILON_MINBODYINERTIA    1.0e-20   // minimum moment of inertia for bodies
#define EP_EPSILON_MINTIMESTEP       1.0e-20   // minimum length of a time step
#define EP_EPSILON_MINCROSSPRODUCT   1.0e-4    // minimum cross product of adjacent edges (convexity check)
#define EP_EPSILON_MINRAILLENGTH     1.0e-6    // minimum length of rail joint 
#define EP_EPSILON_MINPOLYEDGELEN    1.0e-6    // minimum length of polygon edges
#define EP_EPSILON_MINNORMALVECTOR   1.0e-6    // minimum length of a vector that will be normalized
#define EP_EPSILON_MINCONTACTPOINTS  1.0e-4    // minimum distance between two contact points
#define EP_EPSILON_MINCIRCLEVERTEX   1.0e-4    // minimum distance between the center of the circle and a vertex
#define EP_EPSILON_MINBLOCKDET       1.0e-100  // minimum value of the determinant of a block solver matrix

// 32-bit integer types
// used for radix sort
#define ep_int32   signed long
#define ep_uint32  unsigned long

// maximum number of free contacts that will be stored to avoid additional memory allocations
#define EP_MAXFREECONTACTS 100

// size of the buffer used to create debug messages
#define EP_MESSAGE_BUFFERSIZE 2000

// debug message levels
#define EP_MESSAGELEVEL_EXPLICIT         0  // this level of message is sent only when you explicitly ask for it
#define EP_MESSAGELEVEL_ERROR            1  // an error occurred
#define EP_MESSAGELEVEL_IMPORTANTCHANGE  2  // an important change occurred (create, destroy, ...)
#define EP_MESSAGELEVEL_NORMALCHANGE     3  // a normal change occurred (position changed, step, ...)

// shape types
#define EP_SHAPETYPE_BOX      1
#define EP_SHAPETYPE_CIRCLE   2
#define EP_SHAPETYPE_POLYGON  3

// constants
#define EP_PI M_PI
#define EP_MAXDOUBLE DBL_MAX // DBL_MIN = 1e-308, not -1e308! use -EP_MAXDOUBLE instead

// ##### macros #####

#define ep_sqr(x) ((x)*(x))
#define ep_abs(x) (fabs(x))
#define ep_max(a, b) (((a)>(b))? (a) : (b))
#define ep_min(a, b) (((a)<(b))? (a) : (b))
#define ep_clamp(a, b, val) (((val)<(a))? (a) : (((val)>(b))? (b) : (val)))
#define ep_round(x) (floor(0.5+(x)))

// rotates a vector
// [ x' ] = [  cos(a) ,  sin(a) ] * [ x ]
// [ y' ]   [ -sin(a) ,  cos(a) ]   [ y ]
#define ep_transform_x(sin, cos, x, y) (+(cos)*(x)+(sin)*(y))
#define ep_transform_y(sin, cos, x, y) (-(sin)*(x)+(cos)*(y))

// rotates a vector in the opposite direction
// cos(-a) = cos(a)
// sin(-a) = -sin(a)
#define ep_invtransform_x(sin, cos, x, y) (+(cos)*(x)-(sin)*(y))
#define ep_invtransform_y(sin, cos, x, y) (+(sin)*(x)+(cos)*(y))

// combines two transformations
// sin(a+b) = sin(a)*cos(b)+cos(a)*sin(b)
// cos(a+b) = cos(a)*cos(b)-sin(a)*sin(b)
#define ep_totaltransform_sin(sin1, cos1, sin2, cos2) ((sin1)*(cos2)+(cos1)*(sin2))
#define ep_totaltransform_cos(sin1, cos1, sin2, cos2) ((cos1)*(cos2)-(sin1)*(sin2))

// combines a transformation and an inverse transformation
// sin(a-b) = sin(a)*cos(b)-cos(a)*sin(b)
// cos(a-b) = cos(a)*cos(b)+sin(a)*sin(b)
#define ep_totalinvtransform_sin(sin1, cos1, sin2, cos2) ((sin1)*(cos2)-(cos1)*(sin2))
#define ep_totalinvtransform_cos(sin1, cos1, sin2, cos2) ((cos1)*(cos2)+(sin1)*(sin2))

// shuffles indices in an array
// count 5 -> n 5, {0,1,2,3,4} -> {1,3,0,2,4}
// count 6 -> n 7, {0,1,2,3,4,5} -> {1,3,5,0,2,4}
// count 7 -> n 7, {0,1,2,3,4,5,6} -> {1,3,5,0,2,4,6}
// count 8 -> n 9, {0,1,2,3,4,5,6,7} -> {1,3,5,7,0,2,4,6}
#define ep_shuffle_getn(count) ((count)|1)
#define ep_shuffle(iii, nnn) ((((iii)<<1)|1)%(nnn))

// ##### inline functions #####

// You can replace this with your own allocation functions. If memory allocation
// fails, the function should return NULL. If your allocator throws exceptions
// (e.g. std::bad_alloc), you should enable EP_USE_EXCEPTIONS to avoid memory leaks.
// ep_free should never throw
inline void* ep_malloc(unsigned long size) { return malloc(size); }
inline void ep_free(void* mem) { free(mem); }

// ##### class prototypes #####

class ep_Callback;
class ep_Main;

#if EP_COMPILE_MULTIPOLY
struct ep_Multipoly_Vertex;
struct ep_Multipoly_Task;
struct ep_Multipoly_Cut;
#endif // EP_COMPILE_MULTIPOLY
class ep_World;

struct ep_PolygonVertex;
class ep_Polygon;

class ep_Group;
class ep_Body;

struct ep_CollisionData;
struct ep_ContactLink;
struct ep_ContactPoint;
class ep_Contact;

struct ep_HingeJointLink;
class ep_HingeJoint;

struct ep_DistanceJointLink;
class ep_DistanceJoint;

struct ep_RailJointLink;
class ep_RailJoint;

class ep_View;

class ep_Shape;

class ep_Force;

// ##### classes #####

// id hash table
// This is just a very simple hash table to speed up id lookups.

#if EP_USE_IDHASHTABLE
#define EP_IDHASHTABLE_BUCKETS (1<<EP_IDHASHTABLE_BUCKETS_BITS)
#define EP_IDHASHTABLE_BUCKETS_MASK (EP_IDHASHTABLE_BUCKETS-1)
class ep_IdHashTableEntry {
	
	friend class ep_IdHashTable;
	
	public:
	unsigned long id;
	
	private:
	ep_IdHashTableEntry *hashentry_prev, *hashentry_next;
	
};
class ep_IdHashTable {
	
	private:
	ep_IdHashTableEntry *buckets[EP_IDHASHTABLE_BUCKETS];
	
	private:
	EP_FORCEINLINE unsigned int GetBucket(unsigned long id) { return id&EP_IDHASHTABLE_BUCKETS_MASK; }
	
	public:
	EP_FORCEINLINE void Init() {
		for(unsigned int b = 0; b<EP_IDHASHTABLE_BUCKETS; ++b) {
			buckets[b] = NULL;
		}
	}
	EP_FORCEINLINE void Insert(ep_IdHashTableEntry* e) {
		unsigned int b = GetBucket(e->id);
		e->hashentry_prev = NULL;
		if(buckets[b]!=NULL) {
			buckets[b]->hashentry_prev = e;
		}
		e->hashentry_next = buckets[b];
		buckets[b] = e;
	}
	EP_FORCEINLINE void Remove(ep_IdHashTableEntry* e) {
		unsigned int b = GetBucket(e->id);
		if(e->hashentry_prev!=NULL) {
			e->hashentry_prev->hashentry_next = e->hashentry_next;
		} else {
			buckets[b] = e->hashentry_next;
		}
		if(e->hashentry_next!=NULL) {
			e->hashentry_next->hashentry_prev = e->hashentry_prev;
		}
	}
	EP_FORCEINLINE ep_IdHashTableEntry* Find(unsigned long id) {
		unsigned int b = GetBucket(id);
		for(ep_IdHashTableEntry* e = buckets[b]; e!=NULL; e = e->hashentry_next) {
			if(e->id==id) return e;
		}
		return NULL;
	}
	
};
#endif // EP_USE_IDHASHTABLE

// main

/// Returns the version number as a string (e.g. "1.2.34").
const char* ep_Version();

/// ExtremePhysics callback class.
/// Implement this class with your own functions.
/// Whatever you do, DON'T make ANY change to ANY
/// ExtremePhysics object in the callback functions
/// or things will go wrong.
class ep_Callback {
	
	// public functions
	public:
	
	virtual void DebugMessage(int level, const char* string) throw() {}
	
	virtual void DrawBody(bool isstatic, bool issleeping, double x, double y) {}
	virtual void DrawSegment(double x1, double y1, double x2, double y2) {}
	virtual void DrawCircle(double x, double y, double r) {}
	
	virtual void DrawShapeLink(bool isstatic, double x1, double y1, double x2, double y2) {}
	virtual void DrawContactLink(bool isstatic, double x1, double y1, double x2, double y2) {}
	virtual void DrawJointLink(bool isstatic, double x1, double y1, double x2, double y2) {}
	
	virtual void DrawView(double x1, double y1, double x2, double y2) {}
	
	virtual void DrawVelocity(double x, double y, double xvel, double yvel, double rotvel) {}
	virtual void DrawForce(double x, double y, double xforce, double yforce, double torque) {}
	
	virtual void DrawContactPoint(double x1, double y1, double x2, double y2) {}
	virtual void DrawHingeJoint(double x1, double y1, double x2, double y2) {}
	virtual void DrawDistanceJoint(double x1, double y1, double x2, double y2) {}
	virtual void DrawRailJoint(double x1, double y1, double x2a, double y2a, double x2b, double y2b) {}
	
};

/// The main ExtremePhysics class.
/// Create one instance of this class (on the stack or on the heap).
class ep_Main {
	
	friend class ep_World;
	friend class ep_Polygon;
	friend class ep_Body;
	friend class ep_Contact;
	friend class ep_HingeJoint;
	friend class ep_DistanceJoint;
	friend class ep_RailJoint;
	friend class ep_View;
	friend class ep_Shape;
	friend class ep_Force;
	
	// variables
	private:
	
	ep_Callback *callback;
	
	unsigned long idcounter_worlds;
	ep_World *first_world, *last_world, *current_world;
	
	int maxmessagelevel;
	
	unsigned long freecontactcount;
	ep_Contact *freecontacts;
	
	// public functions
	public:
	
	/// Constructor
	/// @param _callback A pointer to an instance of ep_Callback (a derived class).
	ep_Main(ep_Callback* _callback = NULL);
	
	/// Destructor
	~ep_Main();
	
	/// Destroys all ExtremePhysics objects in this world and resets id counters.
	void Clear();
	
	/// Creates a new world.
	/// @param world_userdatasize Size of the userdata memory block for the world.
	/// @param polygon_userdatasize Size of the userdata memory block for polygons.
	/// @param body_userdatasize Size of the userdata memory block for bodies.
	/// @param hingejoint_userdatasize Size of the userdata memory block for hinge joints.
	/// @param distancejoint_userdatasize Size of the userdata memory block for distance joints.
	/// @param railjoint_userdatasize Size of the userdata memory block for rail joints.
	/// @param view_userdatasize Size of the userdata memory block for views.
	/// @param shape_userdatasize Size of the userdata memory block for shapes.
	/// @param force_userdatasize Size of the userdata memory block for forces.
	/// @return Returns a pointer to the new world, or NULL if an error occurred.
	ep_World* CreateWorld(unsigned long world_userdatasize, unsigned long polygon_userdatasize, unsigned long body_userdatasize, unsigned long hingejoint_userdatasize, unsigned long distancejoint_userdatasize, unsigned long railjoint_userdatasize, unsigned long view_userdatasize, unsigned long shape_userdatasize, unsigned long force_userdatasize); //JOINTS//
	/// Destroys a world.
	/// This function will also destroy all bodies, joints, ... associated with this world.
	/// @param world Pointer to the world to destroy.
	/// @return Returns whether successful.
	bool DestroyWorld(ep_World* world);
	/// Finds the world that corresponds to the given id.
	/// @param _id The id of the world.
	/// @return Returns a pointer to the world, or NULL if the world does not exist.
	ep_World* FindWorld(unsigned long _id);
	
	/// Shows a debug message. The format system is identical to printf().
	/// @param level The level of the message.
	/// @param format The format of the message.
	void Message(int level, const char* format, ...);
	/// Lists all ExtremePhysics objects (using debug messages).
	/// This is useful to detect memory leaks.
	void PrintObjectTree();
	
	// public inline functions
	public:
	
	/// Returns a pointer to the first world.
	inline ep_World* GetFirstWorld() { return first_world; }
	/// Returns a pointer to the last world.
	inline ep_World* GetLastWorld() { return last_world; }
	
	/// Sets the message filter.
	/// @param maxmessagelevel Messages with a level higher than this value will be ignored (performance).
	inline void SetMessageFilter(int _maxmessagelevel) { maxmessagelevel = _maxmessagelevel; }
	
};

// world

#if EP_COMPILE_MULTIPOLY
struct ep_Multipoly_Vertex {
	double x, y;
	double nx, ny;
	double segment_nx, segment_ny;
	bool convex;
	unsigned long prev, next;
};
struct ep_Multipoly_Task {
	unsigned long i, j;
	unsigned long a, b;
	ep_Multipoly_Cut *cuts_list1, *cuts_list2;
	int part;
};
struct ep_Multipoly_Cut {
	unsigned long i, j;
	ep_Multipoly_Cut *next;
	int rating1;
	double rating2;
};
#endif // EP_COMPILE_MULTIPOLY
class ep_World {
	
	friend class ep_Main;
	friend class ep_Polygon;
	friend class ep_Body;
	friend class ep_Contact;
	friend class ep_HingeJoint;
	friend class ep_DistanceJoint;
	friend class ep_RailJoint;
	friend class ep_View;
	friend class ep_Shape;
	friend class ep_Force;
	
	// variables
	private:
	
	ep_Main *main;
	ep_World *prev, *next;
	unsigned long id;
	
	unsigned long polygon_userdatasize;
	unsigned long body_userdatasize;
	unsigned long hingejoint_userdatasize;
	unsigned long distancejoint_userdatasize;
	unsigned long railjoint_userdatasize;
	//JOINTS//
	unsigned long view_userdatasize;
	unsigned long shape_userdatasize;
	unsigned long force_userdatasize;
	
	unsigned long idcounter_polygons, polygoncount;
	ep_Polygon *first_polygon, *last_polygon, *current_polygon;
#if EP_USE_IDHASHTABLE
	ep_IdHashTable idhashtable_polygons;
#endif
	
	unsigned long idcounter_bodies, bodycount;
	ep_Body *first_body, *last_body, *current_body;
#if EP_USE_IDHASHTABLE
	ep_IdHashTable idhashtable_bodies;
#endif
	
	unsigned long idcounter_contacts, contactcount;
	ep_Contact *first_contact, *last_contact, *current_contact;
#if EP_USE_IDHASHTABLE
	ep_IdHashTable idhashtable_contacts;
#endif
	
	unsigned long idcounter_hingejoints, hingejointcount;
	ep_HingeJoint *first_hingejoint, *last_hingejoint, *current_hingejoint;
#if EP_USE_IDHASHTABLE
	ep_IdHashTable idhashtable_hingejoints;
#endif
	
	unsigned long idcounter_distancejoints, distancejointcount;
	ep_DistanceJoint *first_distancejoint, *last_distancejoint, *current_distancejoint;
#if EP_USE_IDHASHTABLE
	ep_IdHashTable idhashtable_distancejoints;
#endif
	
	unsigned long idcounter_railjoints, railjointcount;
	ep_RailJoint *first_railjoint, *last_railjoint, *current_railjoint;
#if EP_USE_IDHASHTABLE
	ep_IdHashTable idhashtable_railjoints;
#endif
	
	//JOINTS//
	
	unsigned long idcounter_views, viewcount;
	ep_View *first_view, *last_view, *current_view;
	
	unsigned long shapecount;
	unsigned long forcecount;
	
	double timestep;
	unsigned long velocity_iterations, position_iterations;
	double contact_threshold, velocity_threshold, baumgarte_factor, mass_bias, position_factor;
	bool horizontal;
	
	bool enable_sleeping;
	double time_stable, time_outofview;
	double stable_maxvel, stable_maxrotvel;
	
#if EP_COMPILE_MULTIPOLY
	unsigned long multipoly_vertexcount;
	ep_Multipoly_Vertex *multipoly_vertices;
	ep_Polygon *multipoly_first_polygon, *multipoly_last_polygon;
#endif // EP_COMPILE_MULTIPOLY
	
#if EP_COMPILE_SERIALIZE
	char *serializedata;
	unsigned long serializedata_length;
#endif // EP_COMPILE_SERIALIZE
	
	// private functions
	private:
	
	void Init(ep_Main* _main);
	void DeInit();
	
	bool _UpdateContacts();
	void _UpdateSleeping();
	void IntegrateVelocity();
	void IntegratePosition();
	void SolveVelocityConstraints();
	void SolvePositionConstraints();
	
	ep_Contact* CreateContact(ep_Shape* shape1, ep_Shape* shape2);
	void DestroyContact(ep_Contact* contact);
	
	static bool Collision(ep_CollisionData* data, ep_Shape* shape1, ep_Shape* shape2, double contact_threshold);
	static bool CollisionBoxBox(ep_CollisionData* data, ep_Shape* shape1, ep_Shape* shape2, double contact_threshold);
	static bool CollisionBoxCircle(ep_CollisionData* data, ep_Shape* shape1, ep_Shape* shape2, double contact_threshold);
	static bool CollisionBoxPolygon(ep_CollisionData* data, ep_Shape* shape1, ep_Shape* shape2, double contact_threshold);
	static bool CollisionCircleCircle(ep_CollisionData* data, ep_Shape* shape1, ep_Shape* shape2, double contact_threshold);
	static bool CollisionCirclePolygon(ep_CollisionData* data, ep_Shape* shape1, ep_Shape* shape2, double contact_threshold);
	static bool CollisionPolygonPolygon(ep_CollisionData* data, ep_Shape* shape1, ep_Shape* shape2, double contact_threshold);
	
	void Awake();
	
	// public functions
	public:
	
	/// Destroys all objects in the world and resets id counters.
	void Clear();
	
	/// Finds the contact that corresponds to the given id.
	/// @param _id The id of the contact.
	/// @return Returns a pointer to the contact, or NULL if the contact does not exist.
	ep_Contact* FindContact(unsigned long _id);
	
	/// Creates a new polygon.
	/// @param vertexcount The number of vertices.
	/// @return Returns a pointer to the new polygon, or NULL if an error occurred.
	ep_Polygon* CreatePolygon(unsigned long vertexcount);
	/// Destroys a polygon.
	/// Warning: This function will fail if the polygon is still in use.
	/// @param polygon Pointer to the polygon to destroy.
	/// @return Returns whether successful.
	bool DestroyPolygon(ep_Polygon* polygon);
	/// Finds the polygon that corresponds to the given id.
	/// @param _id The id of the polygon.
	/// @return Returns a pointer to the polygon, or NULL if the polygon does not exist.
	ep_Polygon* FindPolygon(unsigned long _id);
	
	/// Creates a new static body.
	/// @param groundbody Indicates whether the body is a ground body.
	/// @return Returns a pointer to the new body, or NULL if an error occurred.
	ep_Body* CreateStaticBody(bool groundbody);
	/// Creates a new dynamic body.
	/// @param norotation Indicates whether the body can rotate.
	/// @return Returns a pointer to the new body, or NULL if an error occurred.
	ep_Body* CreateDynamicBody(bool norotation);
	/// Destroys a body.
	/// This function will also destroy all shapes, forces and joints associated with this body.
	/// @param body Pointer to the body to destroy.
	/// @return Returns whether successful.
	bool DestroyBody(ep_Body* body);
	/// Finds the body that corresponds to the given id.
	/// @param _id The id of the body.
	/// @return Returns a pointer to the body, or NULL if the body does not exist.
	ep_Body* FindBody(unsigned long _id);
	
	/// Creates a new hinge joint.
	/// @param _body1 Pointer to the first body.
	/// @param _body2 Pointer to the second body.
	/// @param _x1 The x component of the anchor point on the first body.
	/// @param _y1 The y component of the anchor point on the first body.
	/// @param _x2 The x component of the anchor point on the second body.
	/// @param _y2 The y component of the anchor point on the second body.
	/// @param _referencerotation Reference used to calculate the relative rotation of the bodies (rot1-rot2).
	/// @return Returns a pointer to the new hinge joint, or NULL if an error occurred.
	ep_HingeJoint* CreateHingeJoint(ep_Body* body1, ep_Body* body2, double x1, double y1, double x2, double y2, double referencerotation);
	/// Destroys a hinge joint.
	/// @param hingejoint Pointer to the hinge joint to destroy.
	/// @return Returns whether successful.
	bool DestroyHingeJoint(ep_HingeJoint* hingejoint);
	/// Finds the hinge joint that corresponds to the given id.
	/// @param _id The id of the hinge joint.
	/// @return Returns a pointer to the hinge joint, or NULL if the hinge joint does not exist.
	ep_HingeJoint* FindHingeJoint(unsigned long _id);
	
	/// Creates a new distance joint.
	/// @param _body1 Pointer to the first body.
	/// @param _body2 Pointer to the second body.
	/// @param _x1 The x component of the anchor point on the first body.
	/// @param _y1 The y component of the anchor point on the first body.
	/// @param _x2 The x component of the anchor point on the second body.
	/// @param _y2 The y component of the anchor point on the second body.
	/// @return Returns a pointer to the new distance joint, or NULL if an error occurred.
	ep_DistanceJoint* CreateDistanceJoint(ep_Body* body1, ep_Body* body2, double x1, double y1, double x2, double y2);
	/// Destroys a distance joint.
	/// @param distancejoint Pointer to the distance joint to destroy.
	/// @return Returns whether successful.
	bool DestroyDistanceJoint(ep_DistanceJoint* distancejoint);
	/// Finds the distance joint that corresponds to the given id.
	/// @param _id The id of the distance joint.
	/// @return Returns a pointer to the distance joint, or NULL if the hinge joint does not exist.
	ep_DistanceJoint* FindDistanceJoint(unsigned long _id);
	
	/// Creates a new rail joint.
	/// @param _body1 Pointer to the first body.
	/// @param _body2 Pointer to the second body.
	/// @param _x1 The x component of the anchor point on the first body.
	/// @param _y1 The y component of the anchor point on the first body.
	/// @param _x2a The x component of the first anchor point on the second body.
	/// @param _y2a The y component of the first anchor point on the second body.
	/// @param _x2b The x component of the second anchor point on the second body.
	/// @param _y2b The y component of the second anchor point on the second body.
	/// @return Returns a pointer to the new hinge joint, or NULL if an error occurred.
	ep_RailJoint* CreateRailJoint(ep_Body* body1, ep_Body* body2, double x1, double y1, double x2a, double y2a, double x2b, double y2b);
	/// Destroys a rail joint.
	/// @param railjoint Pointer to the rail joint to destroy.
	/// @return Returns whether successful.
	bool DestroyRailJoint(ep_RailJoint* railjoint);
	/// Finds the rail joint that corresponds to the given id.
	/// @param _id The id of the rail joint.
	/// @return Returns a pointer to the rail joint, or NULL if the rail joint does not exist.
	ep_RailJoint* FindRailJoint(unsigned long _id);
	
	//JOINTS//
	
	/// Creates a new view.
	/// @return Returns a pointer to the new view, or NULL if an error occurred.
	ep_View* CreateView();
	/// Destroys a view.
	/// @param world Pointer to the world to destroy.
	/// @return Returns whether successful.
	bool DestroyView(ep_View* view);
	/// Finds the view that corresponds to the given id.
	/// @param id The id of the view.
	/// @return Returns a pointer to the view, or NULL if the world does not exist.
	ep_View* FindView(unsigned long _id);
	
	/// Changes the settings of the world.
	/// @param _timestep The length of one time step. The default value is 1.0.
	/// @param _velocity_iterations The number of iterations used by the velocity solver. Using a higher value increases accuracy. The default value is 20.
	/// @param _position_iterations The number of iterations used by the position solver. Using a higher value increases accuracy. The default value is 10.
	/// @param _contact_threshold The threshold value for collisions. This stops contacts from being destroyed immediately after creation and increases stability.
	/// @param _velocity_threshold The velocity that is lost during collisions. This compensates for the energy collisions add to the system when gravity is used.
	/// @param _baumgarte_factor The bias factor used by the Baumgarte stabilization. Using a lower value will increase stability but decrease accuracy. The default value is 0.1.
	/// @param _mass_bias The bias factor used to calculate the mass of constraints. The best value depends on the complexity of the simulation. The default value is 0.5.
	/// @param _position_factor The bias factor used by the position solver. Using a lower value will sometimes increase stability. The default value is 1.0.
	void SetSettings(double _timestep, unsigned long _velocity_iterations, unsigned long _position_iterations, double _contact_threshold, double _velocity_threshold, double _baumgarte_factor, double _mass_bias, double _position_factor);
	/// Changes the primary axis of the world.
	/// This doesn't change the results but the simulation will be faster if set correctly.
	/// Horizontal scanning is usually faster if there are lots of shapes with similar y-values.
	/// This is often the case when (vertical) gravity is used.
	/// @param _horizontal Indicates whether the world is mostly horizontal. The default value is true.
	void SetPrimaryAxis(bool _horizontal);
	/// Changes the sleeping settings of the world.
	/// @param _enable_sleeping Indicates whether sleeping should be enabled.
	/// @param _time_stable The time objects have to be stable before going to sleep. Set this to 0.0 to disable sleeping for stable objects.
	/// @param _time_outofview The time objects have to be out of view before going to sleep. Set this to 0.0 to disable sleeping for objects that are out of view.
	/// @param _stable_maxvel Bodies with a velocity lower than this value are considered stable.
	/// @param _stable_maxrotvel Bodies with a rotational velocity lower than this value are considered stable.
	void SetSleeping(bool _enable_sleeping, double _time_stable, double _time_outofview, double _stable_maxvel, double _stable_maxrotvel);
	/// Searches collisions and updates contacts.
	/// @return Returns whether successful.
	bool UpdateContacts();
	/// Simulates one time step. Remember to call UpdateContacts first.
	/// @return Returns whether successful.
	bool SimulateStep();
	
#if EP_COMPILE_DEBUGDRAW
	
	/// Draws all bodies in this world using the callback class.
	void DebugDrawBodies();
	/// Draws all pairs (contacts and joints) in this world using the callback class.
	void DebugDrawLinks();
	/// Draws all views in this world using the callback class.
	void DebugDrawViews();
	/// Draws the velocity of all bodies in this world using the callback class.
	void DebugDrawVelocity();
	/// Draws all forces (including contacts and joints) in this world using the callback class.
	void DebugDrawForces();
	/// Draws all points (contacts and joints) in this world using the callback class.
	void DebugDrawConstraints();
	
#endif
	
#if EP_COMPILE_MULTIPOLY
	
	private:
	bool Multipoly_Decompose(bool showerrors);
	void Multipoly_CancelDecompose();
	int Multipoly_MakeTask(ep_Multipoly_Task* result, ep_Multipoly_Cut* cuts, unsigned long first, unsigned long last, ep_Polygon** p, bool showerrors);
	bool Multipoly_IsValidCut(unsigned long i, unsigned long j);
	void Multipoly_CalculateRating(ep_Multipoly_Cut* c);
	
	public:
	/// Begins a new multipolygon
	bool MultipolyBegin(unsigned long vertexcount);
	/// Ends a multipolygon and creates the polygons.
	bool MultipolyEnd(bool showerrors);
	/// Sets the coordinates of a vertex of the multipolygon.
	bool MultipolySetVertex(unsigned long index, double x, double y);
	/// Returns a pointer to the first polygon.
	inline ep_Polygon* MultipolyGetFirst() { return multipoly_first_polygon; }
	/// Returns a pointer to the last polygon.
	inline ep_Polygon* MultipolyGetLast() { return multipoly_last_polygon; }
	
#endif // EP_COMPILE_MULTIPOLY
	
#if EP_COMPILE_SERIALIZE
	
	public:
	// Serializes the world. The state of this world and all related objects (polygons, bodies, contacts, joints, ...) is saved.
	bool Serialize();
	// Frees the serialized data. This is done automatically when the world is destroyed.
	void FreeSerializeData();
	// Unserializes the world.
	bool Unserialize(const char* data, unsigned long length);
	// Returns the serialized data.
	inline const char* GetSerializeData() { return serializedata; }
	// Returns the length of the serialized data.
	inline unsigned long GetSerializeDataLength() { return serializedata_length; }
	
#endif // EP_COMPILE_SERIALIZE
	
	// public inline functions
	public:
	
	/// Returns the id of this world.
	inline unsigned long GetID() { return id; }
	/// Caches the id of this world to speed up the next FindWorld call (if the id matches the id of this world).
	inline void CacheID() { main->current_world = this; }
	/// Returns a pointer to the main ExtremePhysics object associated with this world.
	inline ep_Main* GetMain() { return main; }
	/// Returns a pointer to the previous world.
	inline ep_World* GetPrevious() { return prev; }
	/// Returns a pointer to the next world.
	inline ep_World* GetNext() { return next; }
	/// Returns a pointer to the userdata memory block.
	inline void* GetUserData() { return (void*)(this+1); }
	
	/// Returns a pointer to the first polygon.
	inline ep_Polygon* GetFirstPolygon() { return first_polygon; }
	/// Returns a pointer to the last polygon.
	inline ep_Polygon* GetLastPolygon() { return last_polygon; }
	/// Returns the number of polygons in this world.
	inline unsigned long GetPolygonCount() { return polygoncount; }
	
	/// Returns a pointer to the first body.
	inline ep_Body* GetFirstBody() { return first_body; }
	/// Returns a pointer to the last body.
	inline ep_Body* GetLastBody() { return last_body; }
	/// Returns the number of bodies in this world.
	inline unsigned long GetBodyCount() { return bodycount; }
	
	/// Returns a pointer to the first contact.
	inline ep_Contact* GetFirstContact() { return first_contact; }
	/// Returns a pointer to the last contact.
	inline ep_Contact* GetLastContact() { return last_contact; }
	/// Returns the number of contacts in this world.
	inline unsigned long GetContactCount() { return contactcount; }
	
	/// Returns a pointer to the first hinge joint.
	inline ep_HingeJoint* GetFirstHingeJoint() { return first_hingejoint; }
	/// Returns a pointer to the last hinge joint.
	inline ep_HingeJoint* GetLastHingeJoint() { return last_hingejoint; }
	/// Returns the number of hinge joints in this world.
	inline unsigned long GetHingeJointCount() { return hingejointcount; }
	
	/// Returns a pointer to the first distance joint.
	inline ep_DistanceJoint* GetFirstDistanceJoint() { return first_distancejoint; }
	/// Returns a pointer to the last distance joint.
	inline ep_DistanceJoint* GetLastDistanceJoint() { return last_distancejoint; }
	/// Returns the number of distance joints in this world.
	inline unsigned long GetDistanceJointCount() { return distancejointcount; }
	
	/// Returns a pointer to the first rail joint.
	inline ep_RailJoint* GetFirstRailJoint() { return first_railjoint; }
	/// Returns a pointer to the last rail joint.
	inline ep_RailJoint* GetLastRailJoint() { return last_railjoint; }
	/// Returns the number of rail joints in this world.
	inline unsigned long GetRailJointCount() { return railjointcount; }
	
	//JOINTS//
	
	/// Returns the number of shapes in this world.
	inline unsigned long GetShapeCount() { return shapecount; }
	/// Returns the number of forces in this world.
	inline unsigned long GetForceCount() { return forcecount; }
	
	/// Returns a pointer to the first view.
	inline ep_View* GetFirstView() { return first_view; }
	/// Returns a pointer to the last view.
	inline ep_View* GetLastView() { return last_view; }
	/// Returns the number of views in this world.
	inline unsigned long GetViewCount() { return viewcount; }
	
};

// polygon

struct ep_PolygonVertex {
	double x, y;
	double nx, ny, len, dist, pos;	
};
#if EP_USE_IDHASHTABLE
class ep_Polygon : private ep_IdHashTableEntry {
#else
class ep_Polygon {
#endif
	
	friend class ep_Main;
	friend class ep_World;
	friend class ep_Body;
	friend class ep_Shape;
	
	// variables
	private:
	
	ep_Main *main;
	ep_World *world;
	ep_Polygon *prev, *next;
#if !EP_USE_IDHASHTABLE
	unsigned long id;
#endif
	
	double xoff, yoff;
	double mass;
	double inertia;
	
	unsigned long vertexcount;
	ep_PolygonVertex *vertices;
	
#if EP_COMPILE_DEBUGCHECKS
	unsigned long referencecount;
	bool initialized;
#endif
	
	// private functions
	private:
	
	void Init(ep_World* _world, unsigned long _vertexcount, unsigned long _id);
	void DeInit();
	
	// public functions
	public:
	
	/// Sets the coordinates of a vertex of this polygon.
	/// @param index The index of the vertex, starting from 0.
	/// @param x The x coordinate of the vertex.
	/// @param y The y coordinate of the vertex.
	/// @return Returns whether successful.
	bool SetVertex(unsigned long index, double x, double y);
	/// Initializes this polygon.
	/// @return Returns whether successful.
	bool Initialize();
	
	// inline functions
	public:
	
	/// Returns the id of this polygon.
	inline unsigned long GetID() { return id; }
	/// Caches the id of this polygon to speed up the next FindPolygon call (if the id matches the id of this polygon).
	inline void CacheID() { world->current_polygon = this; }
	/// Returns a pointer to the main ExtremePhysics object associated with this polygon.
	inline ep_Main* GetMain() { return main; }
	/// Returns a pointer to the world associated with this polygon.
	inline ep_World* GetWorld() { return world; }
	/// Returns a pointer to the previous polygon.
	inline ep_Polygon* GetPrevious() { return prev; }
	/// Returns a pointer to the next polygon.
	inline ep_Polygon* GetNext() { return next; }
	/// Returns a pointer to the userdata memory block.
	inline void* GetUserData() { return (void*)((ep_PolygonVertex*)(this+1)+vertexcount); }
	
	/// Returns the number of vertices of this polygon.
	unsigned long GetVertexCount() { return vertexcount; }
	/// Returns the x coordinate of the vertex with the given index.
	double GetVertexX(unsigned long index) {
#if EP_COMPILE_DEBUGCHECKS
		if(index>=vertexcount) {
#if EP_COMPILE_DEBUGMESSAGES
			main->Message(EP_MESSAGELEVEL_ERROR, "Could not get x coordinate of vertex %lu of polygon %lu in world %lu, the polygon has only %lu vertices.", index, id, world->id, vertexcount);
#endif
			return 0.0;
		}
#endif
		return vertices[index].x;
	}
	/// Returns the y coordinate of the vertex with the given index.
	double GetVertexY(unsigned long index) {
#if EP_COMPILE_DEBUGCHECKS
		if(index>=vertexcount) {
#if EP_COMPILE_DEBUGMESSAGES
			main->Message(EP_MESSAGELEVEL_ERROR, "Could not get y coordinate of vertex %lu of polygon %lu in world %lu, the polygon has only %lu vertices.", index, id, world->id, vertexcount);
#endif
			return 0.0;
		}
#endif
		return vertices[index].y;
	}
	/// Returns the x component of the normal vector of the vertex with the given index.
	double GetVertexNormalX(unsigned long index) {
#if EP_COMPILE_DEBUGCHECKS
		if(index>=vertexcount) {
#if EP_COMPILE_DEBUGMESSAGES
			main->Message(EP_MESSAGELEVEL_ERROR, "Could not get x component of normal vector of vertex %lu of polygon %lu in world %lu, the polygon has only %lu vertices.", index, id, world->id, vertexcount);
#endif
			return 0.0;
		}
#endif
		return vertices[index].nx;
	}
	/// Returns the y component of the normal vector of the vertex with the given index.
	double GetVertexNormalY(unsigned long index) {
#if EP_COMPILE_DEBUGCHECKS
		if(index>=vertexcount) {
#if EP_COMPILE_DEBUGMESSAGES
			main->Message(EP_MESSAGELEVEL_ERROR, "Could not get y component of normal vector of vertex %lu of polygon %lu in world %lu, the polygon has only %lu vertices.", index, id, world->id, vertexcount);
#endif
			return 0.0;
		}
#endif
		return vertices[index].ny;
	}
	/// Returns the length of the edge with the given index.
	double GetEdgeLength(unsigned long index) {
#if EP_COMPILE_DEBUGCHECKS
		if(index>=vertexcount) {
#if EP_COMPILE_DEBUGMESSAGES
			main->Message(EP_MESSAGELEVEL_ERROR, "Could not get length of edge %lu of polygon %lu in world %lu, the polygon has only %lu vertices.", index, id, world->id, vertexcount);
#endif
			return 0.0;
		}
#endif
		return vertices[index].len;
	}
	
};

// body

#if EP_COMPILE_BOXCHAIN
struct ep_BoxChain_Vertex {
	double x, y;
	double len;
	double vx, vy, t;
};
#endif // EP_COMPILE_BOXCHAIN
#if EP_USE_IDHASHTABLE
class ep_Body : private ep_IdHashTableEntry {
#else
class ep_Body {
#endif
	
	friend class ep_Main;
	friend class ep_World;
	friend class ep_Contact;
	friend class ep_HingeJoint;
	friend class ep_DistanceJoint;
	friend class ep_RailJoint;
	friend class ep_Shape;
	friend class ep_Force;
	
	// variables
	private:
	
	ep_Main *main;
	ep_World *world;
	ep_Body *prev, *next;
#if !EP_USE_IDHASHTABLE
	unsigned long id;
#endif
	
	unsigned long idcounter_shapes, shapecount;
	ep_Shape *first_shape, *last_shape, *current_shape;
	
	unsigned long idcounter_forces, forcecount;
	ep_Force *first_force, *last_force, *current_force;
	
	bool isgroundbody, isstatic, norotation;
	
	double xoff, yoff;
	double mass, invmass;
	double inertia, invinertia;
	
	double x, y, rot, rot_sin, rot_cos;
	double xvel, yvel, rotvel;
	
	double maxvel, maxrotvel;
	double gravity_x, gravity_y;
	double damping, rotdamping, damping_factor, rotdamping_factor;
	
	bool storecontactimpulses, storejointimpulses;
	bool sleepstable, sleepoutofview, issleeping;
	double stabletimer, outofviewtimer;
	
	union {
		ep_Body *nextislandbody;
#if EP_COMPILE_SERIALIZE
		unsigned long nextislandbody_id;
#endif // EP_COMPILE_SERIALIZE
	};
	
	ep_HingeJointLink *first_hingejointlink, *last_hingejointlink;
	ep_DistanceJointLink *first_distancejointlink, *last_distancejointlink;
	ep_RailJointLink *first_railjointlink, *last_railjointlink;
	//JOINTS//
	
#if EP_COMPILE_BOXCHAIN
	unsigned long boxchain_vertexcount;
	ep_BoxChain_Vertex *boxchain_vertices;
	ep_Shape *boxchain_first_shape, *boxchain_last_shape;
#endif // EP_COMPILE_BOXCHAIN
	
	// private functions
	private:
	
	void Init(ep_World* _world, bool _isgroundbody, bool _isstatic, bool _norotation, unsigned long _id);
	void DeInit();
	
	void Awake(bool linkagechange, bool directchange);
	void Moved();
	
	EP_FORCEINLINE void _ApplyImpulse(double xx, double yy, double xforce, double yforce) {
		xvel += xforce*invmass;
		yvel += yforce*invmass;
		rotvel += (yy*xforce-xx*yforce)*invinertia;
	}
	EP_FORCEINLINE void _ApplyTorque(double torque) {
		rotvel += torque*invinertia;
	}
	EP_FORCEINLINE void _ApplyPseudoImpulse(double xx, double yy, double xforce, double yforce) {
		x += xforce*invmass;
		y += yforce*invmass;
		rot += (yy*xforce-xx*yforce)*invinertia;
		rot_sin = sin(rot);
		rot_cos = cos(rot);
	}
	EP_FORCEINLINE void _ApplyPseudoTorque(double torque) {
		rot += torque*invinertia;
		rot_sin = sin(rot);
		rot_cos = cos(rot);
	}
	
	// public functions
	public:
	
	/// Creates a new box shape.
	/// @param _w The width of the box.
	/// @param _h The height of the box.
	/// @param _x The x coordinate of the center of the shape relative to the body.
	/// @param _y The y coordinate of the center of the shape relative to the body.
	/// @param _rot The rotation of the shape relative to the body.
	/// @param _density The density of the shape.
	/// @return Returns a pointer to the new shape, or NULL if an error occurred.
	ep_Shape* CreateBoxShape(double _w, double _h, double _x, double _y, double _rot, double _density);
	/// Creates a new line shape. This is actually a rotated box shape with height 0.
	/// @param x1 The x component of the first point of the line.
	/// @param y1 The x component of the first point of the line.
	/// @param x2 The x component of the second point of the line.
	/// @param y2 The y component of the second point of the line.
	/// @param _density The density of the shape.
	/// @return Returns a pointer to the new shape, or NULL if an error occurred.
	ep_Shape* CreateLineShape(double x1, double y1, double x2, double y2, double _density);
	/// Creates a new circle shape.
	/// @param _r The radius of the circle.
	/// @param _x The x coordinate of the center of the shape relative to the body.
	/// @param _y The y coordinate of the center of the shape relative to the body.
	/// @param _rot The rotation of the shape relative to the body.
	/// @param _density The density of the shape.
	/// @return Returns a pointer to the new shape, or NULL if an error occurred.
	ep_Shape* CreateCircleShape(double _r, double _x, double _y, double _rot, double _density);
	/// Creates a new polygon shape.
	/// @param polygon Pointer to the polygon.
	/// @param _x The x coordinate of the center of the shape relative to the body.
	/// @param _y The y coordinate of the center of the shape relative to the body.
	/// @param _rot The rotation of the shape relative to the body.
	/// @param _density The density of the shape.
	/// @return Returns a pointer to the new shape, or NULL if an error occurred.
	ep_Shape* CreatePolygonShape(ep_Polygon* polygon, double _x, double _y, double _rot, double _density);
	/// Destroys a shape.
	/// @param world Pointer to the shape to destroy.
	/// @return Returns whether successful.
	bool DestroyShape(ep_Shape* shape);
	/// Finds the shape that corresponds to the given id.
	/// @param id The id of the shape.
	/// @return Returns a pointer to the shape, or NULL if the shape does not exist.
	ep_Shape* FindShape(unsigned long _id);
	
	/// Creates a new force.
	/// @param _x The x coordinate of the local point.
	/// @param _y The y coordinate of the local point.
	/// @param _local Indicates whether the force is local.
	/// @param _ignoremass Indicates whether the mass of the body should be ignored.
	/// @return Returns a pointer to the new world, or NULL if an error occurred.
	ep_Force* CreateForce(double _x, double _y, bool _local, bool _ignoremass);
	/// Destroys a force.
	/// @param force Pointer to the force to destroy.
	/// @return Returns whether successful.
	bool DestroyForce(ep_Force* force);
	/// Finds the force that corresponds to the given id.
	/// @param id The id of the force.
	/// @return Returns a pointer to the force, or NULL if the force does not exist.
	ep_Force* FindForce(unsigned long _id);
	
	/// Returns a pointer to the first hinge joint connected to this body.
	/// @return Returns a pointer to the hinge joint, or NULL if no hinge joint is found.
	ep_HingeJoint* GetFirstHingeJoint();
	/// Returns a pointer to the last hinge joint connected to this body.
	/// @return Returns a pointer to the hinge joint, or NULL if no hinge joint is found.
	ep_HingeJoint* GetLastHingeJoint();
	/// Returns a pointer to the next hinge joint connected to this body.
	/// @param hingejoint Pointer to the current hinge joint.
	/// @return Returns a pointer to the hinge joint, or NULL if no hinge joint is found.
	ep_HingeJoint* GetPreviousHingeJoint(ep_HingeJoint* hingejoint);
	/// Returns a pointer to the previous hinge joint connected to this body.
	/// @param hingejoint Pointer to the current hinge joint.
	/// @return Returns a pointer to the hinge joint, or NULL if no hinge joint is found.
	ep_HingeJoint* GetNextHingeJoint(ep_HingeJoint* hingejoint);
	
	/// Returns a pointer to the first distance joint connected to this body.
	/// @return Returns a pointer to the distance joint, or NULL if no distance joint is found.
	ep_DistanceJoint* GetFirstDistanceJoint();
	/// Returns a pointer to the last distance joint connected to this body.
	/// @return Returns a pointer to the distance joint, or NULL if no distance joint is found.
	ep_DistanceJoint* GetLastDistanceJoint();
	/// Returns a pointer to the next distance joint connected to this body.
	/// @param distancejoint Pointer to the current distance joint.
	/// @return Returns a pointer to the distance joint, or NULL if no distance joint is found.
	ep_DistanceJoint* GetPreviousDistanceJoint(ep_DistanceJoint* distancejoint);
	/// Returns a pointer to the previous distance joint connected to this body.
	/// @param distancejoint Pointer to the current distance joint.
	/// @return Returns a pointer to the distance joint, or NULL if no distance joint is found.
	ep_DistanceJoint* GetNextDistanceJoint(ep_DistanceJoint* distancejoint);
	
	/// Returns a pointer to the first rail joint connected to this body.
	/// @return Returns a pointer to the rail joint, or NULL if no rail joint is found.
	ep_RailJoint* GetFirstRailJoint();
	/// Returns a pointer to the last rail joint connected to this body.
	/// @return Returns a pointer to the rail joint, or NULL if no rail joint is found.
	ep_RailJoint* GetLastRailJoint();
	/// Returns a pointer to the next rail joint connected to this body.
	/// @param railjoint Pointer to the current rail joint.
	/// @return Returns a pointer to the rail joint, or NULL if no rail joint is found.
	ep_RailJoint* GetPreviousRailJoint(ep_RailJoint* railjoint);
	/// Returns a pointer to the previous rail joint connected to this body.
	/// @param railjoint Pointer to the current rail joint.
	/// @return Returns a pointer to the rail joint, or NULL if no rail joint is found.
	ep_RailJoint* GetNextRailJoint(ep_RailJoint* railjoint);
	
	//JOINTS//
	
	/// Calculates the mass, moment of inertia and center of mass of this body based on its shapes.
	/// @return Returns whether successful.
	bool CalculateMass();
	/// Changes the mass of the body.
	/// @param _mass The new mass.
	/// @return Returns whether successful.
	bool SetMass(double _mass);
	/// Changes the moment of inertia of the body.
	/// @param _mass The new moment of inertia.
	/// @return Returns whether successful.
	bool SetInertia(double _inertia);
	/// Changes the center of mass of the body.
	/// @param localx The x coordinate of the new center of mass.
	/// @param localy The y coordinate of the new center of mass.
	/// @param updateinertia Indicates whether to update the moment of inertia (using the parallel axis theorem).
	/// @return Returns whether successful.
	bool SetCenter(double localx, double localy, bool updateinertia);
	/// Changes the position of the body using the origin of the body as the reference.
	/// @param _x The x coordinate of the new position.
	/// @param _y The y coordinate of the new position.
	/// @param _rot The new rotation of the body.
	void SetPosition(double _x, double _y, double _rot);
	/// Changes the position of the body using the center of mass of the body as the reference.
	/// @param _x The x coordinate of the new position.
	/// @param _y The y coordinate of the new position.
	/// @param _rot The new rotation of the body.
	void SetPositionCenter(double _x, double _y, double _rot);
	/// Changes the position of the body using a local point of the body as the reference.
	/// @param _x The x coordinate of the new position.
	/// @param _y The y coordinate of the new position.
	/// @param _rot The new rotation of the body.
	/// @param localx The x coordinate of the reference point (local).
	/// @param localy The y coordinate of the reference point (local).
	void SetPositionLocalPoint(double _x, double _y, double _rot, double localx, double localy);
	/// Changes the velocity of the body using the center of mass of the body as the reference.
	/// @param _xvel The x component of the new velocity of the body.
	/// @param _yvel The y component of the new velocity of the body.
	/// @param _rotvel The new rotational velocity of the body.
	bool SetVelocityCenter(double _xvel, double _yvel, double _rotvel);
	/// Changes the velocity of the body using a local point of the body as the reference.
	/// @param _xvel The x component of the new velocity of the body.
	/// @param _yvel The new y velocity of the body.
	/// @param _rotvel The new rotational velocity of the body.
	/// @param localx The x coordinate of the reference point (local).
	/// @param localy The y coordinate of the reference point (local).
	bool SetVelocityLocalPoint(double _xvel, double _yvel, double _rotvel, double localx, double localy);
	
	/// Changes the maximum velocity of the body.
	/// @param _maxvel The new maximum velocity. Use 0.0 for no limit.
	/// @param _maxrotvel The new maximum rotational velocity. Use 0.0 for no limit.
	bool SetMaxVelocity(double _maxvel, double _maxrotvel);
	/// Changes the gravity of the body, ignoring the mass.
	/// @param _gravity_x The x component of the new gravity of the body.
	/// @param _gravity_y The y component of the new gravity of the body.
	bool SetGravity(double _gravity_x, double _gravity_y);
	/// Changes the damping factors of the body.
	/// @param _damping The new damping factor of the body.
	/// @param _rotdamping The new rotational damping factor of the body.
	bool SetDamping(double _damping, double _rotdamping);
	/// Changes whether impulses are stored for the body.
	/// Impulses are stored only when this setting is set to true for both bodies.
	/// @param _storecontactimpulses Indicates whether contact impulses are stored. The default value is true.
	/// @param _storejointimpulses Indicates whether joint impulses are stored. The default value is true.
	void StoreImpulses(bool _storecontactimpulses, bool _storejointimpulses);
	/// Changes the sleeping settings of the body.
	/// These settings are ignored if sleeping when stable or sleeping out of view is disabled for the world.
	/// @param _sleepstable Indicates whether the body should sleep when it is stable. The default value is true.
	/// @param _sleepoutofview Indicates whether the body should sleep when it is out of view. The default value is true.
	bool SetSleeping(bool _sleepstable, bool _sleepoutofview);
	
#if EP_COMPILE_BOXCHAIN
	/// Begins a new box chain.
	/// @param vertexcount The number of vertices.
	bool BoxChainBegin(unsigned long vertexcount);
	/// Ends the box chain and creates the box shapes.
	/// @param circular Indicates whether this is a circular box chain.
	/// @param ignorefirstlast Indicates whether the first and last boxes should be ignored. This is not used for circular box chains.
	/// @param width_top The width of the top of the box chain when the box chain is defined left-to-right. This can be negative.
	/// @param width_bottom The width of the bottom of the box chain when the box chain is defined left-to-right. This can be negative.
	/// @param density The density of the shapes.
	bool BoxChainEnd(bool circular, bool ignorefirstlast, double width_top, double width_bottom, double density);
	/// Sets the coordinates of a vertex of the box chain.
	bool BoxChainSetVertex(unsigned long index, double x, double y);
	/// Returns a pointer to the first box chain shape.
	inline ep_Shape* BoxChainGetFirst() { return boxchain_first_shape; }
	/// Returns a pointer to the last box chain shape.
	inline ep_Shape* BoxChainGetLast() { return boxchain_last_shape; }
#endif // EP_COMPILE_BOXCHAIN
	
	// public inline functions
	public:
	
	/// Returns the id of this body.
	inline unsigned long GetID() { return id; }
	/// Caches the id of this body to speed up the next FindBody call (if the id matches the id of this body).
	inline void CacheID() { world->current_body = this; }
	/// Returns a pointer to the main ExtremePhysics object associated with this body.
	inline ep_Main* GetMain() { return main; }
	/// Returns a pointer to the world associated with this body.
	inline ep_World* GetWorld() { return world; }
	/// Returns a pointer to the previous body.
	inline ep_Body* GetPrevious() { return prev; }
	/// Returns a pointer to the next body.
	inline ep_Body* GetNext() { return next; }
	/// Returns a pointer to the userdata memory block.
	inline void* GetUserData() { return (void*)(this+1); }
	
	/// Returns a pointer to the first shape.
	inline ep_Shape* GetFirstShape() { return first_shape; }
	/// Returns a pointer to the last shape.
	inline ep_Shape* GetLastShape() { return last_shape; }
	/// Returns the number of shapes for this body.
	inline unsigned long GetShapeCount() { return shapecount; }
	
	/// Returns a pointer to the first polygon.
	inline ep_Force* GetFirstForce() { return first_force; }
	/// Returns a pointer to the last polygon.
	inline ep_Force* GetLastForce() { return last_force; }
	/// Returns the number of forces for this body.
	inline unsigned long GetForceCount() { return forcecount; }
	
	/// Returns the mass of the body.
	inline double GetMass() { return mass; }
	/// Returns the moment of inertia of the body.
	inline double GetInertia() { return inertia; }
	/// Returns the x component of the center of mass of the body.
	inline double GetCenterOfMassX() { return xoff; }
	/// Returns the y component of the center of mass of the body.
	inline double GetCenterOfMassY() { return yoff; }
	
	/// Returns the x coordinate of the body using the origin as the reference.
	inline double GetX() { return x-ep_transform_x(rot_sin, rot_cos, xoff, yoff); }
	/// Returns the y coordinate of the body using the origin as the reference.
	inline double GetY() { return y-ep_transform_y(rot_sin, rot_cos, xoff, yoff); }
	/// Returns the x coordinate of the body using the center of mass as the reference.
	inline double GetXCenter() { return x; }
	/// Returns the y coordinate of the body using the center of mass as the reference.
	inline double GetYCenter() { return y; }
	/// Returns the rotation of the body.
	inline double GetRot() { return rot; }
	
	/// Returns the x velocity of the body using the origin as the reference.
	inline double GetXVelCenter() { return xvel; }
	/// Returns the y velocity of the body using the origin as the reference.
	inline double GetYVelCenter() { return yvel; }
	/// Returns the x coordinate of the body using a local point as the reference.
	inline double GetXVelLocalPoint(double localx, double localy) { return xvel+ep_transform_y(rot_sin, rot_cos, localx-xoff, localy-yoff)*rotvel; }
	/// Returns the y coordinate of the body using a local point as the reference.
	inline double GetYVelLocalPoint(double localx, double localy) { return yvel-ep_transform_x(rot_sin, rot_cos, localx-xoff, localy-yoff)*rotvel; }
	/// Returns the rotational velocity of the body.
	inline double GetRotVel() { return rotvel; }
	
	/// Returns whether the body is static.
	inline bool IsStatic() { return isstatic; }
	/// Returns whether the body is a ground body.
	inline bool IsGroundBody() { return isgroundbody; }
	/// Returns whether the body can't rotate.
	inline bool IsNoRotation() { return norotation; }
	/// Returns whether the body is sleeping.
	inline bool IsSleeping() { return issleeping; }
	/// Returns the time this body has been stable.
	inline double StableTimer() { return stabletimer; }
	/// Returns the time this body has been out of view.
	inline double OutOfViewTimer() { return outofviewtimer; }
	
	/// Coordinate and vector conversions.
	inline double CoordLocalToWorldX(double localx, double localy) { return x+ep_transform_x(rot_sin, rot_cos, localx-xoff, localy-yoff); }
	inline double CoordLocalToWorldY(double localx, double localy) { return y+ep_transform_y(rot_sin, rot_cos, localx-xoff, localy-yoff); }
	inline double CoordWorldToLocalX(double worldx, double worldy) { return xoff+ep_invtransform_x(rot_sin, rot_cos, worldx-x, worldy-y); }
	inline double CoordWorldToLocalY(double worldx, double worldy) { return yoff+ep_invtransform_y(rot_sin, rot_cos, worldx-x, worldy-y); }
	inline double VectLocalToWorldX(double vx, double vy) { return ep_transform_x(rot_sin, rot_cos, vx, vy); }
	inline double VectLocalToWorldY(double vx, double vy) { return ep_transform_y(rot_sin, rot_cos, vx, vy); }
	inline double VectWorldToLocalX(double vx, double vy) { return ep_invtransform_x(rot_sin, rot_cos, vx, vy); }
	inline double VectWorldToLocalY(double vx, double vy) { return ep_invtransform_y(rot_sin, rot_cos, vx, vy); }
	
	/// Applies an impulse.
	/// @param localx The x coordinate of the point of application (local coordinates).
	/// @param localy The y coordinate of the point of application (local coordinates).
	/// @param xforce The x component of the force.
	/// @param yforce The y component of the force.
	/// @param torque The torque.
	/// @param local Indicates whether the force is local.
	/// @param ignoremass Indicates whether the mass and moment of inertia of the body should be ignored.
	/// @param awake Indicates whether the body should be awoken.
	inline void ApplyImpulse(double localx, double localy, double xforce, double yforce, double torque, bool local, bool ignoremass, bool awake) {
#if EP_COMPILE_DEBUGCHECKS
		if(isgroundbody && ignoremass) {
#if EP_COMPILE_DEBUGMESSAGES
			main->Message(EP_MESSAGELEVEL_ERROR, "Could not apply impulse to body %lu in world %lu, the body is a ground body.", id, world->id);
#endif
			return;
		}
#endif
		if(!awake && issleeping) return;
		if(local) {
			xvel += ep_transform_x(rot_sin, rot_cos, xforce, yforce)*((ignoremass)? 1.0 : invmass);
			yvel += ep_transform_y(rot_sin, rot_cos, xforce, yforce)*((ignoremass)? 1.0 : invmass);
			rotvel +=
			  ((localy-yoff)*xforce-(localx-xoff)*yforce)*invinertia*((ignoremass)? mass : 1.0)
			  +torque*((ignoremass)? 1.0 : invinertia);
		} else {
			xvel += xforce*((ignoremass)? 1.0 : invmass);
			yvel += yforce*((ignoremass)? 1.0 : invmass);
			rotvel +=
			  ((localy-yoff)*ep_invtransform_x(rot_sin, rot_cos, xforce, yforce)
			  -(localx-xoff)*ep_invtransform_y(rot_sin, rot_cos, xforce, yforce))*invinertia*((ignoremass)? mass : 1.0)
			  +torque*((ignoremass)? 1.0 : invinertia);
		}
		if(awake) Awake(false, false);
#if EP_COMPILE_DEBUGMESSAGES
		main->Message(EP_MESSAGELEVEL_NORMALCHANGE, "Applied impulse to body %lu in world %lu.", id, world->id);
#endif
	}
	
	/// Applies an impulse to a point relative to the center of mass.
	/// @param relativex The x component of the point of application relative to the center of mass.
	/// @param relativey The y component of the point of application relative to the center of mass.
	/// @param xforce The x component of the force.
	/// @param yforce The y component of the force.
	/// @param torque The torque.
	/// @param ignoremass Indicates whether the mass and moment of inertia of the body should be ignored.
	/// @param awake Indicates whether the body should be awoken.
	inline void ApplyImpulseRelative(double relativex, double relativey, double xforce, double yforce, double torque, bool ignoremass, bool awake) {
#if EP_COMPILE_DEBUGCHECKS
		if(isgroundbody && ignoremass) {
#if EP_COMPILE_DEBUGMESSAGES
			main->Message(EP_MESSAGELEVEL_ERROR, "Could not apply impulse to body %lu in world %lu, the body is a ground body.", id, world->id);
#endif
			return;
		}
#endif
		if(!awake && issleeping) return;
		xvel += xforce*((ignoremass)? 1.0 : invmass);
		yvel += yforce*((ignoremass)? 1.0 : invmass);
		rotvel +=
		  (relativey*xforce-relativex*yforce)*invinertia*((ignoremass)? mass : 1.0)
		  +torque*((ignoremass)? 1.0 : invinertia);
		if(awake) Awake(false, false);
#if EP_COMPILE_DEBUGMESSAGES
		main->Message(EP_MESSAGELEVEL_NORMALCHANGE, "Applied impulse to body %lu in world %lu.", id, world->id);
#endif
	}
	
};

// contact

struct ep_CollisionData {
	double nx, ny;
	bool cp_active[2];
	double cp_x[2][2], cp_y[2][2];
};

struct ep_ContactLink {
	ep_Contact *contact;
	ep_Shape *other_shape;
	ep_ContactLink *prev, *next;
};
struct ep_ContactPoint {
	bool active;
	double x1, y1, x2, y2;
	double xx1, yy1, xx2, yy2;
	double normaltargetvel, tangenttargetvel;
	double normalmass, tangentmass;
	double normalforce, tangentforce;
	double normalveldelta, tangentveldelta;
	double normalpseudoforce;
};
#if EP_USE_IDHASHTABLE
class ep_Contact : private ep_IdHashTableEntry {
#else
class ep_Contact {
#endif
	
	friend class ep_Main;
	friend class ep_World;
	friend class ep_Shape;
	
	// variables
	private:
	
	ep_Main *main;
	ep_World *world;
	ep_Contact *prev, *next;
#if !EP_USE_IDHASHTABLE
	unsigned long id;
#endif
	
	ep_Body *body1, *body2;
	ep_Shape *shape1, *shape2;
	ep_ContactLink link1, link2;
	
	double nx, ny;
	double restitution, friction;
	
	ep_ContactPoint contactpoints[2];
	double m1[2], m2[2];
	int mode;
	
	bool destroy;
	ep_Contact *nextconstraint;
	
	// private functions
	private:
	
	void Init(ep_World* _world, ep_Shape* _shape1, ep_Shape* _shape2, unsigned long _id, bool awake);
	void DeInit();
	
	void Update(ep_CollisionData* data);
	
	void InitCPVelocityConstraints(ep_ContactPoint* cp, double* r1, double* r2);
	void InitVelocityConstraints();
	void ApplyCPImpulses(ep_ContactPoint* cp);
	void ApplyImpulses();
	void BlockSolveCPNormalVelocityConstraints();
	void SolveCPNormalVelocityConstraint(ep_ContactPoint* cp);
	void SolveCPTangentVelocityConstraint(ep_ContactPoint* cp);
	void SolveVelocityConstraints();
	
	void InitPositionConstraints();
	void SolveCPNormalPositionConstraint(ep_ContactPoint* cp);
	void SolvePositionConstraints();
	
	// public functions
	public:
	
	// inline functions
	public:
	
	/// Returns the id of this contact.
	inline unsigned long GetID() { return id; }
	/// Caches the id of this contact to speed up the next FindContact call (if the id matches the id of this contact).
	inline void CacheID() { world->current_contact = this; }
	/// Returns a pointer to the main ExtremePhysics object associated with this contact.
	inline ep_Main* GetMain() { return main; }
	/// Returns a pointer to the world associated with this contact.
	inline ep_World* GetWorld() { return world; }
	/// Returns a pointer to the previous contact.
	inline ep_Contact* GetPrevious() { return prev; }
	/// Returns a pointer to the next contact.
	inline ep_Contact* GetNext() { return next; }
	
	/// Returns a pointer to the first body associated with this contact.
	inline ep_Body* GetBody1() { return body1; }
	/// Returns a pointer to the second body associated with this contact.
	inline ep_Body* GetBody2() { return body2; }
	/// Returns a pointer to the first shape associated with this contact.
	inline ep_Shape* GetShape1() { return shape1; }
	/// Returns a pointer to the second shape associated with this contact.
	inline ep_Shape* GetShape2() { return shape2; }
	
	/// Returns the x component of the normal vector in world coordinates.
	inline double GetNormalX() { return nx; }
	/// Returns the y component of the normal vector in world coordinates.
	inline double GetNormalY() { return ny; }
	
	/// Returns whether the first contact point is active.
	inline bool GetPoint1Active() { return contactpoints[0].active; }
	/// Returns whether the second contact point is active.
	inline bool GetPoint2Active() { return contactpoints[1].active; }
	
	/// Returns the x component of the position of the first contact point (in world coordinates).
	inline double GetPoint1X() {
		return (
		  body1->x+ep_transform_x(body1->rot_sin, body1->rot_cos, contactpoints[0].x1-body1->xoff, contactpoints[0].y1-body1->yoff)+
		  body2->x+ep_transform_x(body2->rot_sin, body2->rot_cos, contactpoints[0].x2-body2->xoff, contactpoints[0].y2-body2->yoff))*0.5;
	}
	/// Returns the y component of the position of the first contact point (in world coordinates).
	inline double GetPoint1Y() {
		return (
		  body1->y+ep_transform_y(body1->rot_sin, body1->rot_cos, contactpoints[0].x1-body1->xoff, contactpoints[0].y1-body1->yoff)+
		  body2->y+ep_transform_y(body2->rot_sin, body2->rot_cos, contactpoints[0].x2-body2->xoff, contactpoints[0].y2-body2->yoff))*0.5;
	}
	/// Returns the x component of the position of the second contact point (in world coordinates).
	inline double GetPoint2X() {
		return (
		  body1->x+ep_transform_x(body1->rot_sin, body1->rot_cos, contactpoints[1].x1-body1->xoff, contactpoints[1].y1-body1->yoff)+
		  body2->x+ep_transform_x(body2->rot_sin, body2->rot_cos, contactpoints[1].x2-body2->xoff, contactpoints[1].y2-body2->yoff))*0.5;
	}
	/// Returns the y component of the position of the second contact point (in world coordinates).
	inline double GetPoint2Y() {
		return (
		  body1->y+ep_transform_y(body1->rot_sin, body1->rot_cos, contactpoints[1].x1-body1->xoff, contactpoints[1].y1-body1->yoff)+
		  body2->y+ep_transform_y(body2->rot_sin, body2->rot_cos, contactpoints[1].x2-body2->xoff, contactpoints[1].y2-body2->yoff))*0.5;
	}
	
	/// Returns the normal force of the first contact point.
	inline double GetPoint1NormalForce() { return contactpoints[0].normalforce; }
	/// Returns the tangent force of the first contact point.
	inline double GetPoint1TangentForce() { return contactpoints[0].tangentforce; }
	/// Returns the normal force of the second contact point.
	inline double GetPoint2NormalForce() { return contactpoints[1].normalforce; }
	/// Returns the tangent force of the second contact point.
	inline double GetPoint2TangentForce() { return contactpoints[1].tangentforce; }
	
	/// Returns the normal velocity difference of the first contact point.
	inline double GetPoint1NormalVelDelta() { return contactpoints[0].normalveldelta; }
	/// Returns the tangent velocity difference of the first contact point.
	inline double GetPoint1TangentVelDelta() { return contactpoints[0].tangentveldelta; }
	/// Returns the normal velocity difference of the second contact point.
	inline double GetPoint2NormalVelDelta() { return contactpoints[1].normalveldelta; }
	/// Returns the tangent velocity difference of the second contact point.
	inline double GetPoint2TangentVelDelta() { return contactpoints[1].tangentveldelta; }
	
};

/*
I did not use inheritance for joints. All joints are completely separate classes.
Using inheritance and virtual functions would probably result in a big performance
penalty because of the number of virtual function calls made by the solver (these
functions are now inlined because it caused a noticeable performance boost).
It might be a good idea to create a separate class for links (contact links + joint links),
this would make the sleeping system more maintainable but it will make the functions that
depend on the separate link lists more complicated and less efficient.
*/

// hinge joint

struct ep_HingeJointLink {
	ep_HingeJoint *hingejoint;
	ep_Body *other_body;
	ep_HingeJointLink *prev, *next;
};
#if EP_USE_IDHASHTABLE
class ep_HingeJoint : private ep_IdHashTableEntry {
#else
class ep_HingeJoint {
#endif
	
	friend class ep_Main;
	friend class ep_World;
	friend class ep_Body;
	
	// variables
	private:
	
	ep_Main *main;
	ep_World *world;
	ep_HingeJoint *prev, *next;
#if !EP_USE_IDHASHTABLE
	unsigned long id;
#endif
	
	ep_Body *body1, *body2;
	ep_HingeJointLink link1, link2;
	
	double x1, y1, x2, y2;
	double referencerotation, maxforce;
	
	double maxmotortorque, motorvel;
	
	double limit1_maxtorque, limit1_rot, limit1_restitution, limit1_velocity;
	double limit2_maxtorque, limit2_rot, limit2_restitution, limit2_velocity;
	double limit_contact_threshold, limit_velocity_threshold;
	double spring1_k, spring1_rotation, spring1_damping;
	double spring2_k, spring2_rotation, spring2_damping;
	
	double xx1, yy1, xx2, yy2, targetvel_x, targetvel_y;
	double targetlimitvel, minlimittorque, maxlimittorque;
	double m1_x, m1_y, m2_x, m2_y, motormass;
	
	double xforce, yforce, motortorque, limittorque;
	double pseudoxforce, pseudoyforce, pseudolimittorque;
	
	ep_HingeJoint *nextconstraint;
	
	// private functions
	private:
	
	void Init(ep_World* _world, ep_Body* _body1, ep_Body* _body2, double _x1, double _y1, double _x2, double _y2, double _referencerotation, unsigned long _id, bool awake);
	void DeInit();
	
	void IntegrateVelocity();
	
	void InitVelocityConstraints();
	void ApplyImpulses();
	void SolveVelocityConstraints();
	
	void InitPositionConstraints();
	void SolvePositionConstraints();
	
	// public functions
	public:
	
	/// Sets the maximum force of this hinge joint
	/// @param _maxforce The new maximum force. Use 0.0 for no limit.
	void SetMaxForce(double _maxforce);
	/// Sets the motor torque and velocity of this hinge joint
	/// @param _maxmotortorque The new maximum motor torque. Use 0.0 to disable the motor.
	/// @param _motorvel The new motor velocity.
	bool SetMotor(double _maxmotortorque, double _motorvel);
	/// Changes the limit settings of the hinge joint.
	/// @param contact_threshold The new contact threshold.
	/// @param velocity_threshold The new velocity threshold.
	void SetLimitSettings(double contact_threshold, double velocity_threshold);
	/// Sets the lower limit of the hinge joint.
	/// @param maxlimittorque The maximum limit torque. Use 0.0 to disable the limit.
	/// @param rotation The lower limit of the rotation.
	/// @param restitution The coefficient of restitution.
	/// @param velocity The velocity of the limit.
	bool SetLowerLimit(double maxlimittorque, double rotation, double restitution, double velocity);
	/// Sets the upper limit of the hinge joint.
	/// @param maxlimittorque The maximum limit torque. Use 0.0 to disable the limit.
	/// @param rotation The upper limit of the rotation.
	/// @param restitution The coefficient of restitution.
	/// @param velocity The velocity of the limit.
	bool SetUpperLimit(double maxlimittorque, double rotation, double restitution, double velocity);
	/// Sets the lower spring of the hinge joint.
	/// @param k The spring constant. Use 0.0 to disable the spring.
	/// @param distance The lower limit.
	/// @param damping The damping force of the spring.
	bool SetLowerSpring(double k, double rotation, double damping);
	/// Sets the upper spring of the hinge joint.
	/// @param k The spring constant. Use 0.0 to disable the spring.
	/// @param distance The lower limit.
	/// @param damping The damping force of the spring.
	bool SetUpperSpring(double k, double rotation, double damping);
	
	// inline functions
	public:
	
	/// Returns the id of this hinge joint.
	inline unsigned long GetID() { return id; }
	/// Caches the id of this hinge joint to speed up the next FindHingeJoint call (if the id matches the id of this hinge joint).
	inline void CacheID() { world->current_hingejoint = this; }
	/// Returns a pointer to the main ExtremePhysics object associated with this hinge joint.
	inline ep_Main* GetMain() { return main; }
	/// Returns a pointer to the world associated with this hinge joint.
	inline ep_World* GetWorld() { return world; }
	/// Returns a pointer to the previous hinge joint.
	inline ep_HingeJoint* GetPrevious() { return prev; }
	/// Returns a pointer to the next hinge joint.
	inline ep_HingeJoint* GetNext() { return next; }
	/// Returns a pointer to the userdata memory block.
	inline void* GetUserData() { return (void*)(this+1); }
	
	/// Returns a pointer to the first body associated with this hinge joint.
	inline ep_Body* GetBody1() { return body1; }
	/// Returns a pointer to the second body associated with this hinge joint.
	inline ep_Body* GetBody2() { return body2; }
	
	/// Returns the current rotation of the hinge joint.
	inline double GetRotation() { return body1->rot-body2->rot-referencerotation; };
	/// Returns the x component of the force applied during the last step.
	inline double GetXForce() { return xforce; };
	/// Returns the y component of the force applied during the last step.
	inline double GetYForce() { return yforce; };
	/// Returns the motor torque applied during the last step.
	inline double GetMotorTorque() { return motortorque; };
	/// Returns the limit torque applied during the last step.
	inline double GetLimitTorque() { return limittorque; };
	
};

// distance joint

struct ep_DistanceJointLink {
	ep_DistanceJoint *distancejoint;
	ep_Body *other_body;
	ep_DistanceJointLink *prev, *next;
};
#if EP_USE_IDHASHTABLE
class ep_DistanceJoint : private ep_IdHashTableEntry {
#else
class ep_DistanceJoint {
#endif
	
	friend class ep_Main;
	friend class ep_World;
	friend class ep_Body;
	
	// variables
	private:
	
	ep_Main *main;
	ep_World *world;
	ep_DistanceJoint *prev, *next;
#if !EP_USE_IDHASHTABLE
	unsigned long id;
#endif
	
	ep_Body *body1, *body2;
	ep_DistanceJointLink link1, link2;
	
	double x1, y1, x2, y2;
	
	double maxmotorforce, motorvel;
	
	double limit1_maxforce, limit1_distance, limit1_restitution, limit1_velocity;
	double limit2_maxforce, limit2_distance, limit2_restitution, limit2_velocity;
	double limit_contact_threshold, limit_velocity_threshold;
	double spring1_k, spring1_distance, spring1_damping;
	double spring2_k, spring2_distance, spring2_damping;
	
	double xx1, yy1, xx2, yy2;
	double vx, vy, distance;
	double targetlimitvel, minlimitforce, maxlimitforce;
	double motormass;
	
	double motorforce, limitforce;
	double pseudolimitforce;
	
	ep_DistanceJoint *nextconstraint;
	
	// private functions
	private:
	
	void Init(ep_World* _world, ep_Body* _body1, ep_Body* _body2, double _x1, double _y1, double _x2, double _y2, unsigned long _id, bool awake);
	void DeInit();
	
	void IntegrateVelocity();
	
	void InitVelocityConstraints();
	void ApplyImpulses();
	void SolveVelocityConstraints();
	
	void InitPositionConstraints();
	void SolvePositionConstraints();
	
	// public functions
	public:
	
	/// Sets the motor force and velocity of this distance joint
	/// @param _maxmotorforce The new maximum motor force. Use 0.0 to disable the motor.
	/// @param _motorvel The new motor velocity.
	void SetMotor(double _maxmotorforce, double _motorvel);
	/// Changes the limit settings of the distance joint.
	/// @param contact_threshold The new contact threshold.
	/// @param velocity_threshold The new velocity threshold.
	void SetLimitSettings(double contact_threshold, double velocity_threshold);
	/// Sets the lower limit of the distance joint.
	/// @param maxlimitforce The maximum limit force. Use 0.0 to disable the limit.
	/// @param distance The lower limit.
	/// @param restitution The coefficient of restitution.
	/// @param velocity The velocity of the limit.
	void SetLowerLimit(double maxlimitforce, double distance, double restitution, double velocity);
	/// Sets the upper limit of the distance joint.
	/// @param maxlimitforce The maximum limit force. Use 0.0 to disable the limit.
	/// @param distance The upper limit.
	/// @param restitution The coefficient of restitution.
	/// @param velocity The velocity of the limit.
	void SetUpperLimit(double maxlimitforce, double distance, double restitution, double velocity);
	/// Sets the lower spring of the distance joint.
	/// @param k The spring constant. Use 0.0 to disable the spring.
	/// @param distance The lower limit.
	/// @param damping The damping force of the spring.
	void SetLowerSpring(double k, double distance, double damping);
	/// Sets the upper spring of the distance joint.
	/// @param k The spring constant. Use 0.0 to disable the spring.
	/// @param distance The lower limit.
	/// @param damping The damping force of the spring.
	void SetUpperSpring(double k, double distance, double damping);
	
	// inline functions
	public:
	
	/// Returns the id of this distance joint.
	inline unsigned long GetID() { return id; }
	/// Caches the id of this distance joint to speed up the next FindDistanceJoint call (if the id matches the id of this distance joint).
	inline void CacheID() { world->current_distancejoint = this; }
	/// Returns a pointer to the main ExtremePhysics object associated with this distance joint.
	inline ep_Main* GetMain() { return main; }
	/// Returns a pointer to the world associated with this distance joint.
	inline ep_World* GetWorld() { return world; }
	/// Returns a pointer to the previous distance joint.
	inline ep_DistanceJoint* GetPrevious() { return prev; }
	/// Returns a pointer to the next distance joint.
	inline ep_DistanceJoint* GetNext() { return next; }
	/// Returns a pointer to the userdata memory block.
	inline void* GetUserData() { return (void*)(this+1); }
	
	/// Returns a pointer to the first body associated with this distance joint.
	inline ep_Body* GetBody1() { return body1; }
	/// Returns a pointer to the second body associated with this distance joint.
	inline ep_Body* GetBody2() { return body2; }
	
	/// Returns the current distance of the distance joint.
	inline double GetDistance() {
		double _vx, _vy;
		_vx = ((body1->x+ep_transform_x(body1->rot_sin, body1->rot_cos, x1-body1->xoff, y1-body1->yoff))-(body2->x+ep_transform_x(body2->rot_sin, body2->rot_cos, x2-body2->xoff, y2-body2->yoff)));
		_vy = ((body1->y+ep_transform_y(body1->rot_sin, body1->rot_cos, x1-body1->xoff, y1-body1->yoff))-(body2->y+ep_transform_y(body2->rot_sin, body2->rot_cos, x2-body2->xoff, y2-body2->yoff)));
		return sqrt(ep_sqr(vx)+ep_sqr(vy));
	}
	/// Returns the motor force applied during the last step.
	inline double GetMotorForce() { return motorforce; };
	/// Returns the limit force applied during the last step.
	inline double GetLimitForce() { return limitforce; };
	
};

// rail joint

struct ep_RailJointLink {
	ep_RailJoint *railjoint;
	ep_Body *other_body;
	ep_RailJointLink *prev, *next;
};
#if EP_USE_IDHASHTABLE
class ep_RailJoint : private ep_IdHashTableEntry {
#else
class ep_RailJoint {
#endif
	
	friend class ep_Main;
	friend class ep_World;
	friend class ep_Body;
	
	// variables
	private:
	
	ep_Main *main;
	ep_World *world;
	ep_RailJoint *prev, *next;
#if !EP_USE_IDHASHTABLE
	unsigned long id;
#endif
	
	ep_Body *body1, *body2;
	ep_RailJointLink link1, link2;
	
	double x1, y1, x2, y2;
	double vx, vy, length;
	
	double maxnormalforce;
	double maxmotorforce, motorvel;
	
	double limit1_maxforce, limit1_position, limit1_restitution, limit1_velocity;
	double limit2_maxforce, limit2_position, limit2_restitution, limit2_velocity;
	double limit_contact_threshold, limit_velocity_threshold;
	double spring1_k, spring1_position, spring1_damping;
	double spring2_k, spring2_position, spring2_damping;
	
	double xx1, yy1, xx2, yy2;
	double vxx, vyy, position, targetnormalvel;
	double targetlimitvel, minlimitforce, maxlimitforce;
	double normalmass, motormass;
	
	double normalforce, motorforce, limitforce;
	double pseudonormalforce, pseudolimitforce;
	
	ep_RailJoint *nextconstraint;
	
	// private functions
	private:
	
	void Init(ep_World* _world, ep_Body* _body1, ep_Body* _body2, double _x1, double _y1, double _x2, double _y2, double _vx, double _vy, double _length, unsigned long _id, bool awake);
	void DeInit();
	
	void IntegrateVelocity();
	
	void InitVelocityConstraints();
	void ApplyImpulses();
	void SolveVelocityConstraints();
	
	void InitPositionConstraints();
	void SolvePositionConstraints();
	
	// public functions
	public:
	
	/// Sets the maximum normal force of this rail joint
	/// @param _maxnormalforce The new maximum normal force. Use 0.0 for no limit.
	void SetMaxNormalForce(double _maxnormalforce);
	/// Sets the motor force and velocity of this rail joint
	/// @param _maxmotorforce The new maximum motor force. Use 0.0 to disable the motor.
	/// @param _motorvel The new motor velocity.
	void SetMotor(double _maxmotorforce, double _motorvel);
	/// Changes the limit settings of the hinge joint.
	/// @param contact_threshold The new contact threshold.
	/// @param velocity_threshold The new velocity threshold.
	void SetLimitSettings(double contact_threshold, double velocity_threshold);
	/// Sets the lower limit of the rail joint.
	/// @param maxlimitforce The maximum limit force. Use 0.0 to disable the limit.
	/// @param position The lower limit.
	/// @param restitution The coefficient of restitution.
	/// @param velocity The velocity of the limit.
	void SetLowerLimit(double maxlimitforce, double position, double restitution, double velocity);
	/// Sets the upper limit of the rail joint.
	/// @param maxlimitforce The maximum limit force. Use 0.0 to disable the limit.
	/// @param position The upper limit.
	/// @param restitution The coefficient of restitution.
	/// @param velocity The velocity of the limit.
	void SetUpperLimit(double maxlimitforce, double position, double restitution, double velocity);
	/// Sets the lower spring of the rail joint.
	/// @param k The spring constant. Use 0.0 to disable the spring.
	/// @param position The lower limit.
	/// @param damping The damping force of the spring.
	void SetLowerSpring(double k, double position, double damping);
	/// Sets the upper spring of the rail joint.
	/// @param k The spring constant. Use 0.0 to disable the spring.
	/// @param position The lower limit.
	/// @param damping The damping force of the spring.
	void SetUpperSpring(double k, double position, double damping);
	
	// inline functions
	public:
	
	/// Returns the id of this rail joint.
	inline unsigned long GetID() { return id; }
	/// Caches the id of this rail joint to speed up the next FindRailJoint call (if the id matches the id of this rail joint).
	inline void CacheID() { world->current_railjoint = this; }
	/// Returns a pointer to the main ExtremePhysics object associated with this rail joint.
	inline ep_Main* GetMain() { return main; }
	/// Returns a pointer to the world associated with this rail joint.
	inline ep_World* GetWorld() { return world; }
	/// Returns a pointer to the previous rail joint.
	inline ep_RailJoint* GetPrevious() { return prev; }
	/// Returns a pointer to the next rail joint.
	inline ep_RailJoint* GetNext() { return next; }
	/// Returns a pointer to the userdata memory block.
	inline void* GetUserData() { return (void*)(this+1); }
	
	/// Returns a pointer to the first body associated with this rail joint.
	inline ep_Body* GetBody1() { return body1; }
	/// Returns a pointer to the second body associated with this rail joint.
	inline ep_Body* GetBody2() { return body2; }
	
	/// Returns the current position of the rail joint.
	inline double GetPosition() {
		return
		  (ep_transform_x(body2->rot_sin, body2->rot_cos, vx, vy)
		   *(body1->x-body2->x
		     +ep_transform_x(body1->rot_sin, body1->rot_cos, x1-body1->xoff, y1-body1->yoff)
		     -ep_transform_x(body2->rot_sin, body2->rot_cos, x2-body2->xoff, y2-body2->yoff))
		  +ep_transform_y(body2->rot_sin, body2->rot_cos, vx, vy)
		   *(body1->y-body2->y
		     +ep_transform_y(body1->rot_sin, body1->rot_cos, x1-body1->xoff, y1-body1->yoff)
		     -ep_transform_y(body2->rot_sin, body2->rot_cos, x2-body2->xoff, y2-body2->yoff)))/length;
	}
	/// Returns the normal force applied during the last step.
	inline double GetNormalForce() { return normalforce; };
	/// Returns the motor force applied during the last step.
	inline double GetMotorForce() { return motorforce; };
	/// Returns the limit force applied during the last step.
	inline double GetLimitForce() { return limitforce; };
	
};

// view

class ep_View {
	
	friend class ep_Main;
	friend class ep_World;
	
	// variables
	private:
	
	ep_Main *main;
	ep_World *world;
	ep_View *prev, *next;
	unsigned long id;
	
	double x1, y1, x2, y2;
	
	// private functions
	private:
	
	void Init(ep_World* _world, unsigned long _id);
	void DeInit();
	
	// public functions
	public:
	
	/// Changes the rectangle of the view.
	/// @param _x1 The left side of the view rectangle.
	/// @param _y1 The top side of the view rectangle.
	/// @param _x2 The right side of the view rectangle.
	/// @param _y2 The bottom side of the view rectangle.
	void SetRectangle(double _x1, double _y1, double _x2, double _y2);
	
	// inline functions
	public:
	
	/// Returns the id of this view.
	inline unsigned long GetID() { return id; }
	/// Caches the id of this view to speed up the next FindView call (if the id matches the id of this view).
	inline void CacheID() { world->current_view = this; }
	/// Returns a pointer to the main ExtremePhysics object associated with this view.
	inline ep_Main* GetMain() { return main; }
	/// Returns a pointer to the world associated with this view.
	inline ep_World* GetWorld() { return world; }
	/// Returns a pointer to the previous view.
	inline ep_View* GetPrevious() { return prev; }
	/// Returns a pointer to the next view.
	inline ep_View* GetNext() { return next; }
	/// Returns a pointer to the userdata memory block.
	inline void* GetUserData() { return (void*)(this+1); }
	
};

// shape

class ep_Shape {
	
	friend class ep_Main;
	friend class ep_World;
	friend class ep_Body;
	friend class ep_Contact;
	
	// variables
	private:
	
	ep_Main *main;
	ep_World *world;
	ep_Body *body;
	ep_Shape *prev, *next;
	unsigned long id;
	
	int shapetype;
	union {
		struct {
			double w, h;
		} box;
		struct {
			double r;
		} circle;
		struct {
			ep_Polygon *polygon;
		} polygon;
	} shapedata;
	
	double x, y, rot, rot_sin, rot_cos, density;
	
	float restitution, friction;
	double normalvelocity, tangentvelocity;
	unsigned long collidemask1, collidemask2, group;
	
	bool updateaabb, updatecontacts;
	double aabb_x1, aabb_y1, aabb_x2, aabb_y2;
	ep_uint32 aabbul_x1, aabbul_y1, aabbul_x2, aabbul_y2;
	double xxx, yyy, sin_t, cos_t;
	ep_Contact *temp_c;
	
	ep_ContactLink *first_contactlink, *last_contactlink;
	
	// private functions
	private:
	
	void Init(ep_Body* _body, int _shapetype, double _x, double _y, double _rot, double _density, double arg1, double arg2, ep_Polygon* arg3, unsigned long _id);
	void DeInit();
	
	void UpdateAABB();
	
	// public functions
	public:
	
	/// Returns a pointer to the first contact connected to this shape.
	/// @return Returns a pointer to the contact, or NULL if no contact is found.
	ep_Contact* GetFirstContact();
	/// Returns a pointer to the last contact connected to this shape.
	/// @return Returns a pointer to the contact, or NULL if no contact is found.
	ep_Contact* GetLastContact();
	/// Returns a pointer to the next contact connected to this shape.
	/// @param hingejoint Pointer to the current contact.
	/// @return Returns a pointer to the contact, or NULL if no contact is found.
	ep_Contact* GetPreviousContact(ep_Contact* contact);
	/// Returns a pointer to the previous contact connected to this shape.
	/// @param hingejoint Pointer to the current contact.
	/// @return Returns a pointer to the contact, or NULL if no contact is found.
	ep_Contact* GetNextContact(ep_Contact* contact);
	
	/// Changes the material of the shape.
	/// @param _restitution The coefficient of restitution.
	/// @param _friction The coefficient of friction.
	/// @param _normalvelocity The normal velocity of the surface.
	/// @param _tangentvelocity The tangent velocity of the surface.
	void SetMaterial(float _restitution, float _friction, double _normalvelocity, double _tangentvelocity);
	/// Changes the collision settings of the shape.
	/// @param _collidemask1 The first collision mask.
	/// @param _collidemask2 The second collision mask.
	/// @param _group The group of the shape. Use zero for no group.
	void SetCollision(unsigned long _collidemask1, unsigned long _collidemask2, unsigned long _group);
	
	/// Performs a collision test with a 'virtual' box shape.
	/// @param w The width of the box.
	/// @param h The height of the box.
	/// @param x The x coordinate of the box.
	/// @param y The y coordinate of the box.
	/// @param rot The rotation of the box.
	/// @param contact_threshold The contact threshold used in the collision test.
	bool CollisionTestBox(double w, double h, double x, double y, double rot, double contact_threshold);
	/// Performs a collision test with a 'virtual' circle shape.
	/// @param r The radius of the circle.
	/// @param x The x coordinate of the circle.
	/// @param y The y coordinate of the circle.
	/// @param contact_threshold The contact threshold used in the collision test.
	bool CollisionTestCircle(double r, double x, double y, double contact_threshold);
	/// Performs a collision test with a 'virtual' polygon shape.
	/// @param polygon The polygon.
	/// @param x The x coordinate of the polygon.
	/// @param y The y coordinate of the polygon.
	/// @param rot The rotation of the polygon.
	/// @param contact_threshold The contact threshold used in the collision test.
	bool CollisionTestPolygon(ep_Polygon* polygon, double x, double y, double rot, double contact_threshold);
	
	// inline functions
	public:
	
	/// Returns the id of this shape.
	inline unsigned long GetID() { return id; }
	/// Caches the id of this shape to speed up the next FindShape call (if the id matches the id of this shape).
	inline void CacheID() { body->current_shape = this; }
	/// Returns a pointer to the main ExtremePhysics object associated with this shape.
	inline ep_Main* GetMain() { return main; }
	/// Returns a pointer to the world associated with this shape.
	inline ep_World* GetWorld() { return world; }
	/// Returns a pointer to the body associated with this shape.
	inline ep_Body* GetBody() { return body; }
	/// Returns a pointer to the previous shape.
	inline ep_Shape* GetPrevious() { return prev; }
	/// Returns a pointer to the next shape.
	inline ep_Shape* GetNext() { return next; }
	/// Returns a pointer to the userdata memory block.
	inline void* GetUserData() { return (void*)(this+1); }
	
};

// force

class ep_Force {
	
	friend class ep_Main;
	friend class ep_World;
	friend class ep_Body;
	
	// variables
	private:
	
	ep_Main *main;
	ep_World *world;
	ep_Body *body;
	ep_Force *prev, *next;
	unsigned long id;
	
	double x, y;
	double xforce, yforce, torque;
	bool local, ignoremass;
	
	// private functions
	private:
	
	void Init(ep_Body* _body, double _x, double _y, bool _local, bool _ignoremass, unsigned long _id);
	void DeInit();
	
	void IntegrateVelocity();
	
	// inline functions
	public:
	
	/// Returns the id of this force.
	inline unsigned long GetID() { return id; }
	/// Caches the id of this force to speed up the next FindForce call (if the id matches the id of this force).
	inline void CacheID() { body->current_force = this; }
	/// Returns a pointer to the main ExtremePhysics object associated with this force.
	inline ep_Main* GetMain() { return main; }
	/// Returns a pointer to the world associated with this force.
	inline ep_World* GetWorld() { return world; }
	/// Returns a pointer to the body associated with this force.
	inline ep_Body* GetBody() { return body; }
	/// Returns a pointer to the previous force.
	inline ep_Force* GetPrevious() { return prev; }
	/// Returns a pointer to the next force.
	inline ep_Force* GetNext() { return next; }
	/// Returns a pointer to the userdata memory block.
	inline void* GetUserData() { return (void*)(this+1); }
	
	/// Changes the force.
	/// @param _xforce The x component of the new force.
	/// @param _yforce The y component of the new force.
	/// @param _torque The new torque.
	inline void SetForce(double _xforce, double _yforce, double _torque, double awake) {
		if(xforce!=_xforce || yforce!=_yforce || torque!=_torque) {
			xforce = _xforce;
			yforce = _yforce;
			torque = _torque;
			if(awake) body->Awake(false, false);
		}
#if EP_COMPILE_DEBUGMESSAGES
		main->Message(EP_MESSAGELEVEL_NORMALCHANGE, "Changed force of force %lu in world %lu.", id, world->id);
#endif
	}
	
};

#endif // EXTREMEPHYSICS_H


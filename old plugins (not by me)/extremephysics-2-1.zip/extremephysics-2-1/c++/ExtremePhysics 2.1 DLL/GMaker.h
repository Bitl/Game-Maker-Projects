/*
 * GMaker - C/C++ Library to enable Game Maker functionality for DLLs.
 * Copyright � 2009 Preston N. Smith
 * (this is a modified version of the original library - Maarten Baert)
 */

#ifndef GMAKER_H
#define GMAKER_H

#ifndef NULL
#define NULL 0
#endif

class GMProc;

class GMVariable {
	
	friend class GMProc;
	
	private:
	int type;
	double real;
	char* string;
	int padding;
	
	public:
	GMVariable() {
		type = 0;
		real = 0.0;
		string = NULL;
		padding = 0;
	}
	GMVariable(double a) {
		type = 0;
		real = a;
		string = NULL;
		padding = 0;
	}
	
};

class GMProc {
	private:
	void *procaddr;
	protected:
	GMProc();
	double ExternalCall(int argcount, GMVariable* args);
	public:
	bool Find(const char* functionname);
};
class GMProc1 : public GMProc {
	public:
	inline double operator()(double arg1) {
		GMVariable args[] = {arg1};
		return ExternalCall(1, args);
	}
};
class GMProc2 : public GMProc {
	public:
	inline double operator()(double arg1, double arg2) {
		GMVariable args[] = {arg1, arg2};
		return ExternalCall(2, args);
	}
};
class GMProc3 : public GMProc {
	public:
	inline double operator()(double arg1, double arg2, double arg3) {
		GMVariable args[] = {arg1, arg2, arg3};
		return ExternalCall(3, args);
	}
};
class GMProc4 : public GMProc {
	public:
	inline double operator()(double arg1, double arg2, double arg3, double arg4) {
		GMVariable args[] = {arg1, arg2, arg3, arg4};
		return ExternalCall(4, args);
	}
};
class GMProc5 : public GMProc {
	public:
	inline double operator()(double arg1, double arg2, double arg3, double arg4, double arg5) {
		GMVariable args[] = {arg1, arg2, arg3, arg4, arg5};
		return ExternalCall(5, args);
	}
};
class GMProc6 : public GMProc {
	public:
	inline double operator()(double arg1, double arg2, double arg3, double arg4, double arg5, double arg6) {
		GMVariable args[] = {arg1, arg2, arg3, arg4, arg5, arg6};
		return ExternalCall(6, args);
	}
};
class GMProc7 : public GMProc {
	public:
	inline double operator()(double arg1, double arg2, double arg3, double arg4, double arg5, double arg6, double arg7) {
		GMVariable args[] = {arg1, arg2, arg3, arg4, arg5, arg6, arg7};
		return ExternalCall(7, args);
	}
};
class GMProc8 : public GMProc {
	public:
	inline double operator()(double arg1, double arg2, double arg3, double arg4, double arg5, double arg6, double arg7, double arg8) {
		GMVariable args[] = {arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8};
		return ExternalCall(8, args);
	}
};

#endif


/*
 * Copyright 2009-2010 Maarten Baert
 * maarten-baert@hotmail.com
 * http://www.maartenbaert.be/
 * 
 * This file is part of ExtremePhysics.
 * 
 * ExtremePhysics is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ExtremePhysics is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with ExtremePhysics. If not, see <http://www.gnu.org/licenses/>.
 * 
 * File: gm_main.cpp
 * Wrapper for ep_Main.
 */

#include "gm.h"

gmexport char* ep_version() {
	return (char*)(ep_Version());
}

gmexport double ep_set_log_file(double enable, char* filename, double level) {
	free(gmcallback.logfile);
	if(gm_cast<bool>(enable)) {
		unsigned long len = strlen(filename);
		gmcallback.logfile = (char*)(malloc(len+1));
		if(gmcallback.logfile==NULL) {
			epmain.SetMessageFilter(1);
			return 0;
		}
		memcpy(gmcallback.logfile, filename, len);
		gmcallback.logfile[len] = '\0';
		epmain.SetMessageFilter((gm_cast<int>(level)>1)? gm_cast<int>(level) : 1);
	} else {
		gmcallback.logfile = NULL;
		epmain.SetMessageFilter(1);
	}
	return 1;
}

gmexport double ep_set_show_errors(double enable) {
	gmcallback.showerrors = gm_cast<bool>(enable);
	return 1;
}

gmexport double ep_message(double level, char* string) {
	epmain.Message(gm_cast<int>(level), "%s", string);
	return 1;
}

gmexport double ep_print_object_tree() {
	epmain.PrintObjectTree();
	return 1;
}

gmexport double ep_first_world() {
	if(epmain.GetFirstWorld()==NULL) {
		return 0;
	}
	epmain.GetFirstWorld()->CacheID();
	return epmain.GetFirstWorld()->GetID();
}

gmexport double ep_last_world() {
	if(epmain.GetLastWorld()==NULL) {
		return 0;
	}
	epmain.GetLastWorld()->CacheID();
	return epmain.GetLastWorld()->GetID();
}


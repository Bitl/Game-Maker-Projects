/*
 * Copyright 2009-2010 Maarten Baert
 * maarten-baert@hotmail.com
 * http://www.maartenbaert.be/
 * 
 * This file is part of ExtremePhysics.
 * 
 * ExtremePhysics is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ExtremePhysics is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with ExtremePhysics. If not, see <http://www.gnu.org/licenses/>.
 * 
 * File: ep_RailJoint_PositionConstraints.h
 * Solves rail joint position constraints.
 * Included in ep_World_SolvePositionConstraints.cpp.
 */

#include "ExtremePhysics.h"

EP_FORCEINLINE void ep_RailJoint::InitPositionConstraints() {
	
	pseudonormalforce = normalforce;
	pseudolimitforce = limitforce;
	
}

EP_FORCEINLINE void ep_RailJoint::SolvePositionConstraints() {
	
	// update relative coordinates
	double current_xx1, current_yy1, current_xx2, current_yy2, current_vxx, current_vyy;
	current_xx1 = ep_transform_x(body1->rot_sin, body1->rot_cos, x1-body1->xoff, y1-body1->yoff);
	current_yy1 = ep_transform_y(body1->rot_sin, body1->rot_cos, x1-body1->xoff, y1-body1->yoff);
	current_xx2 = ep_transform_x(body2->rot_sin, body2->rot_cos, x2-body2->xoff, y2-body2->yoff);
	current_yy2 = ep_transform_y(body2->rot_sin, body2->rot_cos, x2-body2->xoff, y2-body2->yoff);
	current_vxx = ep_transform_x(body2->rot_sin, body2->rot_cos, vx, vy);
	current_vyy = ep_transform_y(body2->rot_sin, body2->rot_cos, vx, vy);
	double railpointx, railpointy, current_position;
	railpointx = body1->x-body2->x+current_xx1;
	railpointy = body1->y-body2->y+current_yy1;
	current_position = current_vxx*(railpointx-current_xx2)+current_vyy*(railpointy-current_yy2);
	current_xx2 += current_vxx*current_position;
	current_yy2 += current_vyy*current_position;
	
	double fx, fy;
	
	// limits
	if(maxlimitforce!=0.0) {
		double r1 = current_yy1*current_vxx-current_xx1*current_vyy;
		double r2 = current_yy2*current_vxx-current_xx2*current_vyy;
		double f = (limit1_position-current_position)*world->position_factor/(
		  body1->invmass+body2->invmass
		  +ep_sqr(r1)*body1->invinertia
		  +ep_sqr(r2)*body2->invinertia);
		if(pseudolimitforce+f<minlimitforce) {
			f = minlimitforce-pseudolimitforce;
			pseudolimitforce = minlimitforce;
		} else if(pseudolimitforce+f>maxlimitforce) {
			f = maxlimitforce-pseudolimitforce;
			pseudolimitforce = maxlimitforce;
		} else {
			pseudolimitforce += f;
		}
		fx = current_vxx*f;
		fy = current_vyy*f;
	} else if(minlimitforce!=0.0) {
		double r1 = current_yy1*current_vxx-current_xx1*current_vyy;
		double r2 = current_yy2*current_vxx-current_xx2*current_vyy;
		double f = (limit2_position-current_position)*world->position_factor/(
		  body1->invmass+body2->invmass
		  +ep_sqr(r1)*body1->invinertia
		  +ep_sqr(r2)*body2->invinertia);
		if(pseudolimitforce+f<minlimitforce) {
			f = minlimitforce-pseudolimitforce;
			pseudolimitforce = minlimitforce;
		} else if(pseudolimitforce+f>maxlimitforce) {
			f = maxlimitforce-pseudolimitforce;
			pseudolimitforce = maxlimitforce;
		} else {
			pseudolimitforce += f;
		}
		fx = current_vxx*f;
		fy = current_vyy*f;
	} else {
		fx = 0.0;
		fy = 0.0;
	}
	
	// normal constraint
	{
		double r1 = current_yy1*current_vyy+current_xx1*current_vxx;
		double r2 = current_yy2*current_vyy+current_xx2*current_vxx;
		double f = (current_vxx*(railpointy-current_yy2)-current_vyy*(railpointx-current_xx2))*world->position_factor/(
		  body1->invmass+body2->invmass
		  +ep_sqr(r1)*body1->invinertia
		  +ep_sqr(r2)*body2->invinertia);
		
		// clamp pseudoforce
		if(maxnormalforce==0.0) {
			pseudonormalforce += f;
		} else {
			if(f<-maxnormalforce-pseudonormalforce) {
				f = -maxnormalforce-pseudonormalforce;
				pseudonormalforce = -maxnormalforce;
			} else if(f>+maxnormalforce-pseudonormalforce) {
				f = +maxnormalforce-pseudonormalforce;
				pseudonormalforce = +maxnormalforce;
			} else {
				pseudonormalforce += f;
			}
		}
		
		fx += +f*current_vyy;
		fy += -f*current_vxx;
	}
	
	// apply pseudoforce
	body1->_ApplyPseudoImpulse(xx1, yy1, +fx, +fy);
	body2->_ApplyPseudoImpulse(xx2, yy2, -fx, -fy);
	
}


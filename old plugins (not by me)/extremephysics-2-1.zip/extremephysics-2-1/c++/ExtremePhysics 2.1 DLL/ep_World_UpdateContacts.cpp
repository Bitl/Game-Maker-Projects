/*
 * Copyright 2009-2010 Maarten Baert
 * maarten-baert@hotmail.com
 * http://www.maartenbaert.be/
 * 
 * This file is part of ExtremePhysics.
 * 
 * ExtremePhysics is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ExtremePhysics is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with ExtremePhysics. If not, see <http://www.gnu.org/licenses/>.
 * 
 * File: ep_World_UpdateContacts.cpp
 * Updates contacts for the simulation.
 */

#include "ExtremePhysics.h"

#include "ep_Contact_Update.h"

/*
Portability warning:
This code assumes sizeof(double)==8.
*/

EP_FORCEINLINE void RadixSort(const ep_uint32 values[], unsigned long indices[], unsigned long temp[], unsigned long count) {
	// A very fast linear time sorting algorithm for unsigned integers
	// The algorithm sorts the list once for every radix (byte)
	// using counting sort (a stable sorting algorithm).
	// The array of values will not be sorted, only the indices
	// (and temp) are changed by the algorithm.
	
	unsigned long counters[4*256];
	unsigned long offsets[256];
	
	// erase counters
	for(unsigned long *p = counters; p!=counters+4*256;) {
		*(p++) = 0;
	}
	
	// fill counters
	{
		for(unsigned char *radix = (unsigned char*)(values), *stop = (unsigned char*)(values+count); radix!=stop;) {
			++counters[*(radix++)+256*0];
			++counters[*(radix++)+256*1];
			++counters[*(radix++)+256*2];
			++counters[*(radix++)+256*3];
		}
	}
	
	// radix sort
	for(unsigned int j = 0; j<4; ++j) {
		
		// fill offsets
		unsigned long *counter = counters+256*j;
		unsigned long cumsum = 0;
		offsets[0] = 0;
		for(unsigned long *p = offsets+1; p!=offsets+256;) {
			*(p++) = cumsum += *(counter++);
		}
		
		// sort
		unsigned char *input = (unsigned char*)(values)+j;
		for(unsigned long *ind = indices, *stop = indices+count; ind!=stop;) {
			unsigned long i = *(ind++);
			temp[offsets[input[4*i]]++] = i;
		}
		
		// swap indices
		{
			unsigned long *t;
			t = indices;
			indices = temp;
			temp = t;
		}
		
	}
	
}

bool ep_World::_UpdateContacts() {
	// Based on Pierre Terdiman's Radix Sweep-And-Prune (Radix SAP).
	// http://www.codercorner.com/SweepAndPrune.htm
	// It's basically the same as SAP, but it's not incremental.
	// When there are lots of small, fast moving bodies (eg. particles)
	// this is a lot better (normal SAP will waste time looking
	// for coherence even when there is no coherence). When there
	// are no moving bodies Radix SAP is about 50% slower.
	
	// set 'destroy' flag
	for(ep_Contact *contact = first_contact; contact!=NULL; contact = contact->next) {
		contact->destroy = (contact->shape1->updatecontacts || contact->shape2->updatecontacts);
	}
	
	// update and count shapes and get world size
	unsigned long shapecount = 0;
	for(ep_Body *body = first_body; body!=NULL; body = body->next) {
		for(ep_Shape *shape = body->first_shape; shape!=NULL; shape = shape->next) {
			shape->UpdateAABB();
			++shapecount;
		}
	}
	
	if(shapecount<2) return true;
	
	//TODO// add separate code for bodies that are already up-to-date (performance)
	// four groups:
	// - normal
	// - no update
	// required checks:
	// - normal vs normal (old code)
	// - normal vs no update
	// 'no update' usually includes ground bodies
	
	//TODO// store the temporary array for other collision functions (performance)
	// temp array should be managed by a different function (like UpdateAABB)
	
	// create temporary array for sorting
	void *temparray = ep_malloc(shapecount*sizeof(ep_Shape*)+shapecount*sizeof(ep_uint32)+2*shapecount*sizeof(unsigned long));
	if(temparray==NULL) {
#if EP_COMPILE_DEBUGMESSAGES
		main->Message(EP_MESSAGELEVEL_ERROR, "Could not initialize simulation in world %lu, memory allocation of temporary AABB array failed.", id);
#endif
		return false;
	}
	ep_Shape **shapes = (ep_Shape**)(temparray);
	ep_uint32 *x1_array = (ep_uint32*)(shapes+shapecount);
	unsigned long *sorted    = (unsigned long*)(x1_array+shapecount);
	unsigned long *temp      = (unsigned long*)(sorted+shapecount);
	
	// fill temporary array
	{
		unsigned long i = 0;
		for(ep_Body *body = first_body; body!=NULL; body = body->next) {
			for(ep_Shape *shape = body->first_shape; shape!=NULL; shape = shape->next) {
				
				// Surjection from double to ep_uint32.
				// Precision is not important here and
				// radix sort uses ep_uint32.
				// Originally I used "(f<0)? f^0xffffffff : f^0x80000000"
				// but the bitwise method described at
				// http://www.stereopsis.com/radix.html
				// is probably faster.
				double d;
				ep_uint32 f;
				
				d = (horizontal)? shape->aabb_x1 : shape->aabb_y1;
				f = *((ep_uint32*)(&d)+1);
				shape->aabbul_x1 = f^((-(ep_int32)(f>>31))|0x80000000);
				
				d = (horizontal)? shape->aabb_y1 : shape->aabb_x1;
				f = *((ep_uint32*)(&d)+1);
				shape->aabbul_y1 = f^((-(ep_int32)(f>>31))|0x80000000);
				
				d = (horizontal)? shape->aabb_x2+contact_threshold : shape->aabb_y2+contact_threshold;
				f = *((ep_uint32*)(&d)+1);
				shape->aabbul_x2 = f^((-(ep_int32)(f>>31))|0x80000000);
				
				d = (horizontal)? shape->aabb_y2+contact_threshold : shape->aabb_x2+contact_threshold;
				f = *((ep_uint32*)(&d)+1);
				shape->aabbul_y2 = f^((-(ep_int32)(f>>31))|0x80000000);
				
				shapes[i] = shape;
				x1_array[i] = shape->aabbul_x1;
				sorted[i] = i; // it's not sorted yet, after sorting the indices will be in a different order
				++i;
				
			}
		}
	}
	
	// sort
	RadixSort(x1_array, sorted, temp, shapecount);
	
	// SAP (Sweep And Prune)
	{
		unsigned long *stop = sorted+shapecount;
		for(unsigned long *pos1 = sorted; pos1!=stop; ++pos1) {
			ep_uint32 x2 = shapes[*pos1]->aabbul_x2;
			ep_uint32 y1 = shapes[*pos1]->aabbul_y1;
			ep_uint32 y2 = shapes[*pos1]->aabbul_y2;
			
			// first pass (clear temp_c)
			for(unsigned long *pos2 = pos1+1; pos2!=stop && x1_array[*pos2]<=x2; ++pos2) {
				if(shapes[*pos2]->aabbul_y1<=y2 && y1<=shapes[*pos2]->aabbul_y2) {
					shapes[*pos2]->temp_c = NULL;
				}
			}
			
			// find existing contacts
			for(ep_ContactLink *cl = shapes[*pos1]->first_contactlink; cl!=NULL; cl = cl->next) {
				cl->other_shape->temp_c = cl->contact;
			}
			
			// second pass (update contacts)
			for(unsigned long *pos2 = pos1+1; pos2!=stop && x1_array[*pos2]<=x2; ++pos2) {
				if(shapes[*pos2]->aabbul_y1<=y2 && y1<=shapes[*pos2]->aabbul_y2) {
					// the AABBs overlap, update contacts
					
					// flip shapes?
					ep_Shape *shape1 = shapes[ep_min(*pos1, *pos2)];
					ep_Shape *shape2 = shapes[ep_max(*pos1, *pos2)];
					
					// Shapes that belong to the same body can't collide,
					// static bodies can't collide, and updating is not
					// required if the shapes didn't move.
					if(shape1->body==shape2->body || (shape1->body->isstatic && shape2->body->isstatic) || (!shape1->updatecontacts && !shape2->updatecontacts)) {
						continue;
					}
					
					// Do the collision masks and groups match?
					if(((shape1->collidemask1&shape2->collidemask2)==0 && (shape2->collidemask1&shape1->collidemask2)==0)
					  || (shape1->group==shape2->group && shape1->group!=0)) {
						continue;
					}
					
					// create new contact?
					ep_Contact *contact = shapes[*pos2]->temp_c;
					ep_CollisionData cd;
					if(Collision(&cd, shape1, shape2, (contact==NULL)? -contact_threshold : contact_threshold)) {
						if(contact==NULL) {
#if EP_USE_EXCEPTIONS
							try {
#endif
							contact = CreateContact(shape1, shape2); // awakes the bodies
#if EP_USE_EXCEPTIONS
							}
							catch(...) {
								ep_free(temparray);
								throw;
							}
#endif
							if(contact==NULL) {
								ep_free(temparray);
								return false;
							}
						}
						contact->Update(&cd);
						contact->destroy = false;
					}
					
				}
			}
			
		}
	}
	
	ep_free(temparray);
	
	// destroy invalid contacts
	for(ep_Contact *contact = first_contact, *t; contact!=NULL; contact = t) {
		t = contact->next;
		if(contact->destroy) {
			DestroyContact(contact); // this will awake the bodies
		}
	}
	
	for(ep_Body *body = first_body; body!=NULL; body = body->next) {
		for(ep_Shape *shape = body->first_shape; shape!=NULL; shape = shape->next) {
			shape->updatecontacts = false;
		}
	}
	
	return true;
	
}


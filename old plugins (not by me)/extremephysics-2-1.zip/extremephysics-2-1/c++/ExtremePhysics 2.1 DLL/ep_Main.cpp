/*
 * Copyright 2009-2010 Maarten Baert
 * maarten-baert@hotmail.com
 * http://www.maartenbaert.be/
 * 
 * This file is part of ExtremePhysics.
 * 
 * ExtremePhysics is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ExtremePhysics is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with ExtremePhysics. If not, see <http://www.gnu.org/licenses/>.
 * 
 * File: ep_Main.cpp
 * Implementation of ep_Main.
 */

#include "ExtremePhysics.h"

const char* ep_Version() {
	return "2.1.14";
}

ep_Main::ep_Main(ep_Callback* _callback) {
	
	callback = _callback;
	
	idcounter_worlds = 0;
	first_world = NULL;
	last_world = NULL;
	current_world = NULL;
	
	maxmessagelevel = 1;
	
	freecontactcount = 0;
	freecontacts = NULL;
	
}

ep_Main::~ep_Main() {
	
	// destroy everything
	while(first_world!=NULL) DestroyWorld(first_world);
	
	// destroy free contacts
	while(freecontacts!=NULL) {
		ep_Contact *t = freecontacts->next;
		ep_free(freecontacts);
		freecontacts = t;
	}
	
}

void ep_Main::Clear() {
	
	// destroy everything
	while(first_world!=NULL) DestroyWorld(first_world);
	
	// reset id counters
	idcounter_worlds = 0;
	
}

// world

ep_World* ep_Main::CreateWorld(unsigned long world_userdatasize, unsigned long polygon_userdatasize, unsigned long body_userdatasize, unsigned long hingejoint_userdatasize, unsigned long distancejoint_userdatasize, unsigned long railjoint_userdatasize, unsigned long view_userdatasize, unsigned long shape_userdatasize, unsigned long force_userdatasize) { //JOINTS//
	ep_World *world;
	
	// allocate memory
	world = (ep_World*)(ep_malloc(sizeof(ep_World)+world_userdatasize));
	if(world==NULL) {
#if EP_COMPILE_DEBUGMESSAGES
		Message(EP_MESSAGELEVEL_ERROR, "Could not create world, memory allocation failed.");
#endif
		return NULL;
	}
	
	world->polygon_userdatasize = polygon_userdatasize;
	world->body_userdatasize = body_userdatasize;
	world->hingejoint_userdatasize = hingejoint_userdatasize;
	world->distancejoint_userdatasize = distancejoint_userdatasize;
	world->railjoint_userdatasize = railjoint_userdatasize;
	//JOINTS//
	world->view_userdatasize = view_userdatasize;
	world->shape_userdatasize = shape_userdatasize;
	world->force_userdatasize = force_userdatasize;
	world->Init(this);
	
#if EP_COMPILE_DEBUGMESSAGES
	Message(EP_MESSAGELEVEL_IMPORTANTCHANGE, "Created world %lu.", world->id);
#endif
	
	return world;
}

bool ep_Main::DestroyWorld(ep_World* world) {
	
	world->DeInit();
#if EP_COMPILE_DEBUGMESSAGES
	unsigned long _id = world->id;
#endif
	ep_free(world);
#if EP_COMPILE_DEBUGMESSAGES
	Message(EP_MESSAGELEVEL_IMPORTANTCHANGE, "Destroyed world %lu.", _id);
#endif
	
	return true;
}

ep_World* ep_Main::FindWorld(unsigned long _id) {
	if(current_world!=NULL) {
		if(current_world->id==_id) return current_world;
	}
	for(current_world = first_world; current_world!=NULL; current_world = current_world->next) {
		if(current_world->id==_id) return current_world;
	}
	return NULL;
}

// other

void ep_Main::Message(int level, const char* format, ...) {
	if(level<=maxmessagelevel) {
		va_list args;
		va_start(args, format);
		char messagebuffer[EP_MESSAGE_BUFFERSIZE+1];
#ifdef _MSC_VER
		// VC++ complains about deprecation
		_vsnprintf_s(messagebuffer, EP_MESSAGE_BUFFERSIZE+1, EP_MESSAGE_BUFFERSIZE, format, args);
#else
		vsnprintf(messagebuffer, EP_MESSAGE_BUFFERSIZE, format, args);
#endif
		messagebuffer[EP_MESSAGE_BUFFERSIZE] = '\0';
		va_end(args);
		callback->DebugMessage(level, messagebuffer);
	}
}

void ep_Main::PrintObjectTree() {
	
	/*
	Object tree:
	+- Main
	   +- World 1
	   |  +- Body 1
	   |  |  +- Shape 1
	   |  |  +- Shape 2
	   |  +- Body 2
	   |  |  +- Shape 1
	   |  +- Body 3
	   |     +- Shape 1
	   |     +- Shape 2
	   |     +- Shape 3
	   +- World 2
	End of object tree.
	*/
	
	Message(EP_MESSAGELEVEL_EXPLICIT, "Object tree:");
	Message(EP_MESSAGELEVEL_EXPLICIT, "+- Main");
	for(ep_World *world = first_world; world!=NULL; world = world->next) {
		Message(EP_MESSAGELEVEL_EXPLICIT, "   +- World %lu",
		        world->id);
		for(ep_Polygon *polygon = world->first_polygon; polygon!=NULL; polygon = polygon->next) {
			Message(EP_MESSAGELEVEL_EXPLICIT, "   %c  +- Polygon %lu (%lu vertices, %s)",
			        (world->next==NULL)? ' ' : '|',
			        polygon->id, polygon->vertexcount,
			        (polygon->initialized)? "initialized" : "not initialized");
		}
		for(ep_Body *body = world->first_body; body!=NULL; body = body->next) {
			Message(EP_MESSAGELEVEL_EXPLICIT, "   %c  +- Body %lu (%s)",
			        (world->next==NULL)? ' ' : '|',
			        body->id,
			        (body->isstatic)? ((body->isgroundbody)? "static + ground body" : "static")
			                        : ((body->norotation)? "dynamic + no rotation" : "dynamic"));
			for(ep_Shape *shape = body->first_shape; shape!=NULL; shape = shape->next) {
				switch(shape->shapetype) {
					case EP_SHAPETYPE_BOX: {
						Message(EP_MESSAGELEVEL_EXPLICIT, "   %c  %c  +- Shape %lu (box)",
						        (world->next==NULL)? ' ' : '|',
						        (body->next==NULL)? ' ' : '|',
						        shape->id);
						break;
					}
					case EP_SHAPETYPE_CIRCLE: {
						Message(EP_MESSAGELEVEL_EXPLICIT, "   %c  %c  +- Shape %lu (circle)",
						        (world->next==NULL)? ' ' : '|',
						        (body->next==NULL)? ' ' : '|',
						        shape->id);
						break;
					}
					case EP_SHAPETYPE_POLYGON: {
						Message(EP_MESSAGELEVEL_EXPLICIT, "   %c  %c  +- Shape %lu (polygon %lu)",
						        (world->next==NULL)? ' ' : '|',
						        (body->next==NULL)? ' ' : '|',
						        shape->id, shape->shapedata.polygon.polygon->id);
						break;
					}
				}
			}
			for(ep_Force *force = body->first_force; force!=NULL; force = force->next) {
				Message(EP_MESSAGELEVEL_EXPLICIT, "   %c  %c  +- Force %lu (%s)",
				        (world->next==NULL)? ' ' : '|',
				        (body->next==NULL)? ' ' : '|',
				        force->id,
				        (force->local)? ((force->ignoremass)? "local + ignoring mass" : "local")
				                      : ((force->ignoremass)? "global + ignoring mass" : "global"));
			}
		}
		for(ep_Contact *contact = world->first_contact; contact!=NULL; contact = contact->next) {
			Message(EP_MESSAGELEVEL_EXPLICIT, "   %c  +- Contact %lu (connected to shape %lu of body %lu and shape %lu of body %lu)",
			        (world->next==NULL)? ' ' : '|',
			        contact->id, contact->shape1->id, contact->body1->id, contact->shape2->id, contact->body2->id);
		}
		for(ep_HingeJoint *hingejoint = world->first_hingejoint; hingejoint!=NULL; hingejoint = hingejoint->next) {
			Message(EP_MESSAGELEVEL_EXPLICIT, "   %c  +- Hinge Joint %lu (connected to body %lu and body %lu)",
			        (world->next==NULL)? ' ' : '|',
			        hingejoint->id, hingejoint->body1->id, hingejoint->body2->id);
		}
		for(ep_DistanceJoint *distancejoint = world->first_distancejoint; distancejoint!=NULL; distancejoint = distancejoint->next) {
			Message(EP_MESSAGELEVEL_EXPLICIT, "   %c  +- Distance Joint %lu (connected to body %lu and body %lu)",
			        (world->next==NULL)? ' ' : '|',
			        distancejoint->id, distancejoint->body1->id, distancejoint->body2->id);
		}
		for(ep_RailJoint *railjoint = world->first_railjoint; railjoint!=NULL; railjoint = railjoint->next) {
			Message(EP_MESSAGELEVEL_EXPLICIT, "   %c  +- Rail Joint %lu (connected to body %lu and body %lu)",
			        (world->next==NULL)? ' ' : '|',
			        railjoint->id, railjoint->body1->id, railjoint->body2->id);
		}
		//JOINTS//
		for(ep_View *view = world->first_view; view!=NULL; view = view->next) {
			Message(EP_MESSAGELEVEL_EXPLICIT, "   %c  +- View %lu",
			        (world->next==NULL)? ' ' : '|',
			        view->id);
		}
	}
	Message(EP_MESSAGELEVEL_EXPLICIT, "End of object tree.");
	
}


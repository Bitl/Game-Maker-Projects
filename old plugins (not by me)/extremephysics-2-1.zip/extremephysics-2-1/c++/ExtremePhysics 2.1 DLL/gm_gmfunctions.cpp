/*
 * Copyright 2009-2010 Maarten Baert
 * maarten-baert@hotmail.com
 * http://www.maartenbaert.be/
 * 
 * This file is part of ExtremePhysics.
 * 
 * ExtremePhysics is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ExtremePhysics is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with ExtremePhysics. If not, see <http://www.gnu.org/licenses/>.
 * 
 * File: gm_gmfunctions.cpp
 * GMaker-related functions.
 */

#include "gm.h"

bool gmfunctions_initialized = false;
GMProc1 GM_draw_set_color;
GMProc4 GM_draw_circle;
GMProc4 GM_draw_line;
GMProc5 GM_draw_line_width;
GMProc5 GM_draw_arrow;
GMProc5 GM_draw_rectangle;

gmexport double ep_gm_functions_init() {
	if(gmfunctions_initialized) return 1;
	if(!GM_draw_set_color   .Find("draw_set_color"))   return 0;
	if(!GM_draw_circle      .Find("draw_circle"))      return 0;
	if(!GM_draw_line        .Find("draw_line"))        return 0;
	if(!GM_draw_line_width  .Find("draw_line_width"))  return 0;
	if(!GM_draw_arrow       .Find("draw_arrow"))       return 0;
	if(!GM_draw_rectangle   .Find("draw_rectangle"))   return 0;
	gmfunctions_initialized = true;
	return 1;
}


GMCap Version 0.5.0.0b by Ravotus

Thank you for downloading GMCap! GMCap is an extension for Game Maker which has many features for recording
AVI files. Just some of these are:

	Compression dialog which supports all codecs installed on the user's system
	Add frames from any window as well as bitmap files
	Multi-threaded, so no game hangs
	Add frames from a specific region on the screen by specifying coordinates
	Take screenshots of any window, multi-threaded as well
	Optionally draw the cursor on any screenshot or AVI frame
	Extensive error reporting system
	Compatible with GM 5.3A, 6, and 7
	
GMCap is great for trailers, in game cutscenes, game teasers, and much more!

GMCap is free to use for free and commercial use. Include Ravotus in your credits if you use this extension.
You may use this extension in any way you wish as long as you do not claim it as your own. I am not liable
for any damages caused to you or anything caused by this extension.

As always, if you enjoy this extension, let me know! Or, send me money. :)
Usage:
     For GameMaker 6.1 and lesser:
	merge the file "XMLParser_V4_ScriptsOnly.gm6" into your
	current game to import the scripts and their folder hierarchy.

     For GameMaker 7.0 Unregistered users:
	merge the file "XMLParser_V4_ScriptsOnly.gm6" into your
	current game to import the scripts and their folder hierarchy,
	NOTE: These scripts were optimized for GM6.0 and 6.1 NOT 7.0!

     For GameMaker 7.0 Registered Users:
	Click on the Extensions button and add the "XMLParser_V4.gex"
	extension to your list.
	NOTE: The scripts in the extension package were converted for maximum
	efficiency in GM7.0

Thanks for downloading and using my scripts,
I hope that they prove useful to you,

-Major
